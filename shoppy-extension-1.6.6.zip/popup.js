document.addEventListener('DOMContentLoaded', async () => {
  // 현재 환경 체크 및 사용자 안내
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const status = document.getElementById('status');
    
    if (activeTab && (activeTab.url.startsWith('chrome://') || activeTab.url.startsWith('edge://'))) {
      if (status) {
        status.innerHTML = '<span style="color: orange;">⚠️ Chrome 내부 페이지에서는 번역 기능을 사용할 수 없습니다.<br>일반 웹사이트로 이동 후 다시 시도해주세요.</span>';
      }
    } else if (activeTab && activeTab.url.startsWith('file://')) {
      if (status) {
        status.innerHTML = '<span style="color: orange;">⚠️ 로컬 파일에서는 번역 기능을 사용할 수 없습니다.<br>웹사이트에서 시도해주세요.</span>';
      }
    } else if (activeTab) {
      if (status) {
        status.innerHTML = '<span style="color: green;">✅ 번역 준비 완료</span>';
      }
    }
  } catch (error) {
    console.log('환경 체크 오류:', error);
  }
  function getTargetTabId() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get('targetTabId', async (result) => {
        if (result.targetTabId) {
          // 탭 ID가 유효한지 확인하고, chrome:// URL이 아닌지 검증
          try {
            const tab = await chrome.tabs.get(result.targetTabId);
            if (tab && !tab.url.startsWith('chrome://') && !tab.url.startsWith('edge://')) {
              resolve(result.targetTabId);
              return;
            } else if (tab && (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://'))) {
              reject(new Error("chrome:// 또는 edge:// URL에서는 스크립트를 실행할 수 없습니다. 일반 웹페이지에서 시도해주세요."));
              return;
            }
          } catch (error) {
            // 저장된 탭 ID가 유효하지 않은 경우, 현재 활성 탭으로 폴백
            log(`저장된 탭 ID(${result.targetTabId})가 유효하지 않음, 현재 활성 탭 사용`);
          }
        }
        
        // 저장된 탭이 없거나 유효하지 않은 경우, 현재 활성 탭 사용
        try {
          const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (activeTab && !activeTab.url.startsWith('chrome://') && !activeTab.url.startsWith('edge://')) {
            // 새로운 활성 탭 ID를 저장
            chrome.storage.local.set({ targetTabId: activeTab.id });
            resolve(activeTab.id);
          } else {
            reject(new Error("현재 탭이 chrome:// 또는 edge:// URL입니다. 일반 웹페이지에서 시도해주세요."));
          }
        } catch (error) {
          reject(new Error("대상 탭을 찾을 수 없습니다."));
        }
      });
    });
  }

  async function log(message) {
    const timestamp = new Date().toLocaleTimeString();
    const logMessage = `[${timestamp}] ${message}\n`;
    const logText = document.getElementById('logText') || { value: '', scrollTop: 0 };
    logText.value += logMessage;
    logText.scrollTop = logText.scrollHeight;

    const logs = await new Promise(resolve =>
      chrome.storage.local.get(['logs'], result => resolve(result.logs || ''))
    );
    const logLines = logs.split('\n').slice(-1000).join('\n') + logMessage;
    await new Promise(resolve => chrome.storage.local.set({ logs: logLines }, resolve));
  }

  // 청크에서 지침을 불러오는 함수
  async function loadInstructionFromChunks(key) {
    try {
      // 청크 개수 확인
      const { [`${key}_chunks`]: chunkCount } = await new Promise(resolve => {
        chrome.storage.sync.get([`${key}_chunks`], resolve);
      });
      
      if (!chunkCount) return '';
      
      // 청크 키 생성
      const chunkKeys = Array.from({ length: chunkCount }, (_, i) => `${key}_chunk_${i}`);
      
      // 모든 청크 로드
      const chunks = await new Promise(resolve => {
        chrome.storage.sync.get(chunkKeys, items => {
          resolve(chunkKeys.map(k => items[k] || ''));
        });
      });
      
      // 청크 합치기
      return chunks.join('');
    } catch (error) {
      log(`${key} 청크 로드 오류: ${error.message}`);
      throw error;
    }
  }

  const runButton = document.getElementById('runButton');
  const bulkTranslateButton = document.getElementById('bulkTranslateButton');
  const status = document.getElementById('status');
  const spinner = document.getElementById('spinner');

  log(`runButton: ${runButton ? '존재' : '없음'}`);
  log(`bulkTranslateButton: ${bulkTranslateButton ? '존재' : '없음'}`);

  // 전체 이미지 번역 버튼 이벤트 리스너
  if (bulkTranslateButton) {
    bulkTranslateButton.addEventListener('click', async () => {
      try {
        const tabId = await getTargetTabId();
        log('전체 이미지 번역 시작');
        
        chrome.scripting.executeScript({
          target: { tabId: tabId },
          function: () => {
            if (window.P_TRANSLATE) {
              if (window.P_TRANSLATE.running) {
                window.P_TRANSLATE.stop();
              } else {
                window.P_TRANSLATE.runAll();
              }
            } else {
              console.warn('P_TRANSLATE 객체를 찾을 수 없습니다. 퍼센티 이미지 에디터 페이지에 있는지 확인하세요.');
            }
          }
        }, (results) => {
          if (chrome.runtime.lastError) {
            log(`전체 이미지 번역 실행 오류: ${chrome.runtime.lastError.message}`);
          } else {
            log('전체 이미지 번역 명령 실행됨');
          }
        });
      } catch (error) {
        log(`전체 이미지 번역 오류: ${error.message}`);
      }
    });
  } else {
    log('bulkTranslateButton 요소를 찾을 수 없음');
  }

  if (runButton) {
    runButton.addEventListener('click', async () => {
      status.textContent = '실행 중...';
      spinner.style.display = 'block';
      runButton.disabled = true;
      log('프로그램 시작');

      try {
        // 기본 설정 로드
        const { apiKey, gptModel, shortcutKey } = await new Promise(resolve =>
          chrome.storage.sync.get(['apiKey', 'gptModel', 'shortcutKey'], resolve)
        );
        
        // 지침 데이터 청크 방식으로 로드 (옵션명 번역은 옵션명 지침만 사용)
        const instruction = await loadInstructionFromChunks('instruction');
        
        log(`로드된 설정 - API 키: ${apiKey ? '설정됨' : '없음'}, 모델: ${gptModel || '없음'}, 옵션명 지침: ${instruction ? '있음' : '없음'}, 단축키: ${shortcutKey || '없음'}`);
        if (!apiKey) throw new Error('API 키가 설정되지 않았습니다.');
        if (!instruction) throw new Error('옵션명 지침이 설정되지 않았습니다.');

        log(`사용된 옵션명 지침: ${instruction}`);

        // DOM 상태 최신화 및 텍스트 추출
        const { texts, textSources } = await new Promise((resolve, reject) => {
          getTargetTabId().then((tabId) => {
            chrome.scripting.executeScript(
              {
                target: { tabId: tabId, allFrames: false },
                function: () => {
                  const texts = [];
                  const textSources = {};
                  
                  // 체크박스 상태 최신 확인
                  const checkedItems = Array.from(document.querySelectorAll('li.ant-list-item'));
                  checkedItems.forEach((item, index) => {
                    const checkbox = item.querySelector('input[type="checkbox"][checked]');
                    if (checkbox) {
                      const span = item.querySelector('span.CharacterSecondary45');
                      const text = span ? span.textContent.trim() : null;
                      if (text && (text.match(/[\u4e00-\u9fff]/) || text.match(/[a-zA-Z]/))) {
                        texts.push(text);
                        textSources[text] = 'checkbox';
                      }
                    }
                  });

                  return { texts, textSources };
                },
              },
              (results) => {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                resolve(results[0]?.result || { texts: [], textSources: {} });
              }
            );
          }).catch(reject);
        });

        log(`최종 추출된 텍스트: ${texts.join(', ')}`);
        if (texts.length === 0) throw new Error('추출된 텍스트가 없습니다.');

        // 옵션명 번역은 모든 텍스트를 옵션명 지침으로 통합 처리
        log(`옵션명 텍스트 수: ${texts.length}`);

        // 번역 진행 (옵션명 지침만 사용)
        const translatedTexts = [];
        if (texts.length > 0) {
          const translations = await translateTexts(texts, apiKey, gptModel, instruction);
          texts.forEach((text, i) => {
            // 번역 결과를 지침 그대로 사용 (추가 가공 없음)
            translatedTexts.push(translations[i]);
          });
        }

        log(`번역된 텍스트: ${translatedTexts.join(', ')}`);

        await replaceTexts(texts, translatedTexts);
        log('텍스트 리플레이스 완료');
        status.textContent = '완료!';
      } catch (error) {
        log(`오류: ${error.message}`);
        status.textContent = `오류: ${error.message}`;
      } finally {
        spinner.style.display = 'none';
        runButton.disabled = false;
      }
    });
  } else {
    log('runButton 요소를 찾을 수 없음');
  }

  // 설정 버튼 이벤트 리스너 - options.html 열기
  const settingsButton = document.getElementById('settingsButton');
  if (settingsButton) {
    settingsButton.addEventListener('click', async () => {
      log('설정 버튼 클릭 시도');
      try {
        await new Promise((resolve, reject) => {
          chrome.runtime.openOptionsPage(() => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve();
            }
          });
        });
        log('옵션 페이지 열림');
      } catch (error) {
        log(`openOptionsPage 오류: ${error.message}`);
        const optionsUrl = chrome.runtime.getURL('options.html');
        log(`대체 URL로 시도: ${optionsUrl}`);
        chrome.windows.create({
          url: optionsUrl,
          type: 'popup',
          width: 400,
          height: 600
        }, () => log('대체 옵션 페이지 열림'));
      }
    });
  } else {
    log('settingsButton 요소를 찾을 수 없음');
  }

  chrome.commands.onCommand.addListener((command) => {
    if (command === 'run-extension') {
      if (runButton) runButton.click();
      else log('runButton이 없어 단축키 실행 불가');
    } else if (command === 'run-bulk-translation') {
      if (bulkTranslateButton) bulkTranslateButton.click();
      else log('bulkTranslateButton이 없어 단축키 실행 불가');
    }
  });

  async function verifyDOMState() {
    return new Promise((resolve, reject) => {
      getTargetTabId().then((tabId) => {
        chrome.scripting.executeScript(
          {
            target: { tabId: tabId, allFrames: false },
            function: () => {
              const texts = [];
              const textSources = {};
              
              // 체크박스 상태 재확인
              const checkedItems = Array.from(document.querySelectorAll('li.ant-list-item'));
              checkedItems.forEach((item, index) => {
                const checkbox = item.querySelector('input[type="checkbox"][checked]');
                if (checkbox) {
                  const span = item.querySelector('span.CharacterSecondary45');
                  const text = span ? span.textContent.trim() : null;
                  if (text && (text.match(/[\u4e00-\u9fff]/) || text.match(/[a-zA-Z]/))) {
                    texts.push(text);
                    textSources[text] = 'checkbox';
                  }
                }
              });

              return { texts, textSources };
            },
          },
          (results) => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            resolve(results[0]?.result || { texts: [], textSources: {} });
          }
        );
      }).catch(reject);
    });
  }

  // 기존 extractChineseTexts 함수 수정
  async function extractChineseTexts() {
    try {
      // DOM 상태 재확인
      const verifiedState = await verifyDOMState();
      log(`DOM 상태 재확인 완료: ${verifiedState.texts.length}개의 텍스트 발견`);
      return verifiedState;
    } catch (error) {
      log(`DOM 상태 재확인 실패: ${error.message}`);
      throw error;
    }
  }

  async function translateTexts(texts, apiKey, gptModel, instruction) {
    const translations = [];
    const finalInstruction = instruction;
    if (!finalInstruction) throw new Error('지침이 설정되지 않았습니다.');

    try {
      const combinedText = texts.join('\n');
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: gptModel || 'gpt-4-turbo-preview',
          messages: [
            { role: 'system', content: finalInstruction },
            { role: 'user', content: `다음 중국어 옵션들을 번역해줘. 각 옵션은 반드시 한 줄로 번역하고, 번호나 불릿 포인트 없이 번역 결과만 출력해주세요. 각 줄은 앞뒤 공백 없이 출력하세요:\n${combinedText}` },
          ],
          temperature: 0.3,
          top_p: 0.95,
          max_tokens: 2000,
        }),
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error.message);

      let translatedLines = data.choices[0].message.content.split('\n');
      
      if (translatedLines.length !== texts.length) {
        log(`번역된 줄 수 불일치 감지: 예상 ${texts.length}개, 실제 ${translatedLines.length}개`);
        
        // 줄 수가 더 많은 경우 앞에서부터 필요한 만큼만 사용
        if (translatedLines.length > texts.length) {
          translatedLines = translatedLines.slice(0, texts.length);
        } else {
          // 줄 수가 부족한 경우 재시도
          log('번역 재시도 중...');
          return await translateTexts(texts, apiKey, gptModel, instruction);
        }
      }

      translatedLines.forEach((translation, index) => {
        const originalText = texts[index];
        
        // 지침에서만 모든 처리를 하도록 함 (코드 간섭 완전 제거)
        // 단, 지침에 명시된 앞뒤 공백 제거는 코드에서 보장
        const cleanTranslation = translation.trim();
        
        translations.push(cleanTranslation);
        log(`번역 완료: ${originalText} -> ${cleanTranslation}`);
      });
    } catch (error) {
      log(`번역 오류: ${error.message}`);
      throw error;
    }
    return translations;
  }

  async function replaceTexts(originalTexts, translatedTexts) {
    return new Promise((resolve, reject) => {
      getTargetTabId().then((tabId) => {
        chrome.tabs.update(tabId, { active: true }, () => {
          chrome.scripting.executeScript(
            {
              target: { tabId: tabId, allFrames: false },
              function: (originalTexts, translatedTexts) => {
                // 1. 체크박스 항목 처리
                const checkedItems = Array.from(document.querySelectorAll('li.ant-list-item'));
                checkedItems.forEach((item, index) => {
                  const checkbox = item.querySelector('input[type="checkbox"][checked]');
                  if (checkbox) {
                    const span = item.querySelector('span.CharacterSecondary45');
                    const originalText = span ? span.textContent.trim() : null;
                    if (originalText) {
                      const textIndex = originalTexts.indexOf(originalText);
                      if (textIndex !== -1) {
                        const translatedValue = translatedTexts[textIndex];
                        console.log(`[Replace] 체크박스 텍스트 교체: "${originalText}" -> "${translatedValue}"`);
                        const inputWrapper = item.querySelector('span.ant-input-affix-wrapper');
                        if (inputWrapper) {
                          const input = inputWrapper.querySelector('input.ant-input');
                          if (input) {
                            input.focus();
                            input.select();
                            input.value = translatedValue;
                            input.dispatchEvent(new Event('input', { bubbles: true }));
                            input.dispatchEvent(new Event('change', { bubbles: true }));
                            console.log(`[Replace] 체크박스 입력 완료: ${translatedValue}`);
                          }
                        }
                      } else {
                        console.log(`[Replace] 체크박스 텍스트 매칭 실패: "${originalText}"`);
                      }
                    }
                  }
                });

                // 2. 웹페이지 중국어 텍스트 처리
                const elements = document.querySelectorAll('.sc-eBMEME.jgkSWq.Body3Regular14.CharacterSecondary45');
                elements.forEach((element) => {
                  const originalText = element.textContent.trim();
                  if (originalText.match(/[\u4e00-\u9fff]/)) {
                    const textIndex = originalTexts.indexOf(originalText);
                    if (textIndex !== -1) {
                      const translatedValue = translatedTexts[textIndex];
                      
                      // 중국어 요소가 있는 컨테이너 찾기
                      const container = element.closest('.sc-eBMEME.iMna-dW');
                      if (container) {
                        // 해당 컨테이너에서 한국어 번역이 들어있는 두 번째 div 찾기
                        const koreanElements = container.querySelectorAll('.sc-eBMEME.jgkSWq.Body3Regular14.CharacterSecondary45');
                        if (koreanElements.length > 1) {
                          // 두 번째 요소가 한국어 번역 텍스트를 가지고 있음
                          const koreanElement = koreanElements[1];
                          console.log(`한국어 텍스트 요소 찾음: ${koreanElement.textContent}`);
                          koreanElement.textContent = translatedValue;
                          console.log(`한국어 텍스트 변경됨: ${translatedValue}`);
                        }
                      }
                      
                      // 상위 컨테이너에서 input 필드 찾기 (상품명 입력 필드)
                      const parentContainer = element.closest('.sc-eBMEME.dBJpVO');
                      if (parentContainer) {
                        const inputWrapper = parentContainer.querySelector('.ant-input-affix-wrapper');
                        if (inputWrapper) {
                          const input = inputWrapper.querySelector('input.ant-input');
                          if (input) {
                            console.log(`상품명 입력 필드 찾음: ${input.value}`);
                            input.focus();
                            input.select();
                            input.value = translatedValue;
                            input.dispatchEvent(new Event('input', { bubbles: true }));
                            input.dispatchEvent(new Event('change', { bubbles: true }));
                            console.log(`상품명 입력 필드 변경됨: ${translatedValue}`);
                          }
                        }
                      }
                      
                      // 기존 코드 유지 (다른 페이지에서 사용될 수 있음)
                      const productInputWrappers = document.querySelectorAll('.ant-input-affix-wrapper');
                      productInputWrappers.forEach(wrapper => {
                        const input = wrapper.querySelector('input.ant-input');
                        if (input && input.value === originalText) {
                          console.log(`상품명 input 찾음: ${input.value}`);
                          input.focus();
                          input.select();
                          input.value = translatedValue;
                          input.dispatchEvent(new Event('input', { bubbles: true }));
                          input.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                      });
                    }
                  }
                });
              },
              args: [originalTexts, translatedTexts],
            },
            (results) => {
              if (chrome.runtime.lastError) {
                log(`리플레이스 오류: ${chrome.runtime.lastError.message}`);
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(results);
              }
            }
          );
        });
      }).catch(reject);
    });
  }

  function observeLayerPopup() {
    getTargetTabId().then((tabId) => {
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        function: () => {
          function addCustomButton(popupElement) {
            if (!popupElement.querySelector('#customButton')) {
              const btn = document.createElement('button');
              btn.id = 'customButton';
              btn.textContent = 'Custom Action';
              btn.style.position = 'fixed';
              btn.style.top = '10px';
              btn.style.right = '10px';
              btn.style.zIndex = '9999';
              btn.style.padding = '8px 12px';
              btn.style.backgroundColor = '#4a90e2';
              btn.style.color = '#fff';
              btn.style.border = 'none';
              btn.style.borderRadius = '5px';
              btn.style.cursor = 'pointer';
              popupElement.appendChild(btn);
            }
          }
          const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
              mutation.addedNodes.forEach((node) => {
                if (node.nodeType === Node.ELEMENT_NODE && node.classList.contains('layer-popup')) {
                  addCustomButton(node);
                }
              });
            });
          });
          observer.observe(document.body, { childList: true, subtree: true });
        },
      });
    }).catch((error) => {
      log(`observeLayerPopup 오류: ${error.message}`);
    });
  }

  observeLayerPopup();

  // 버전 체크 및 업데이트 알림 시스템
  async function initVersionChecker() {
    try {
      log('VersionChecker 초기화 시작...');
      const versionChecker = new VersionChecker();
      log('VersionChecker 인스턴스 생성 완료');
      
      // 현재 버전 표시 (HTML에 직접 설정된 버전 사용)
      const currentVersionElement = document.getElementById('currentVersion');
      if (currentVersionElement) {
        // HTML에 이미 v1.4.0으로 설정되어 있으므로 그대로 유지
        const displayVersion = currentVersionElement.textContent;
        log(`현재 버전 표시: ${displayVersion}`);
      }

      // 저장된 업데이트 정보 확인
      log('저장된 업데이트 정보 확인 중...');
      let updateInfo = await versionChecker.getPendingUpdate();
      log(`저장된 업데이트 정보: ${updateInfo ? '있음' : '없음'}`);
      
      // 저장된 정보가 없거나 체크가 필요한 경우 새로 확인 (테스트용으로 항상 체크)
      const shouldCheck = await versionChecker.shouldCheckNow();
      log(`체크 필요 여부: ${shouldCheck}`);
      
      if (!updateInfo || shouldCheck) {
        log('새 버전 확인 중...');
        try {
          updateInfo = await versionChecker.performVersionCheck();
          log(`performVersionCheck 완료: ${updateInfo ? '결과 있음' : '결과 없음'}`);
          
          if (updateInfo) {
            log(`업데이트 정보 상세: hasUpdate=${updateInfo.hasUpdate}, error=${updateInfo.error}`);
          }
        } catch (versionCheckError) {
          log(`performVersionCheck 중 오류: ${versionCheckError.message}`);
          console.error('[버전체크] performVersionCheck 오류:', versionCheckError);
          updateInfo = null;
        }
        
        // 버전 체크 결과 로그 표시
        if (updateInfo && updateInfo.hasUpdate) {
          log(`🔄 업데이트 발견: v${updateInfo.currentVersion} → v${updateInfo.latestVersion}`);
        } else if (updateInfo && !updateInfo.hasUpdate && !updateInfo.error) {
          log('✅ 연결 확인 완료 - 최신 버전입니다.');
        } else if (updateInfo && updateInfo.error) {
          // 구체적인 오류 상황별 메시지
          switch(updateInfo.error) {
            case 'NO_RELEASE':
              log('⚠️ 연결 확인 완료 - 릴리즈(새로운 업데이트) 없음');
              break;
            case 'AUTH_FAILED':
              log('❌ 연결 실패 - GitHub Token 오류');
              break;
            case 'API_ERROR':
              log(`❌ 연결 실패 - GitHub API 오류 (${updateInfo.status})`);
              break;
            case 'NETWORK_ERROR':
              log('❌ 연결 실패 - 네트워크 오류');
              break;
            case 'INVALID_RESPONSE':
              log('❌ 연결 실패 - 유효하지 않은 응답');
              break;
            default:
              log(`❌ 연결 실패 - ${updateInfo.errorMessage || '알 수 없는 오류'}`);
          }
        } else {
          log('❌ 버전 체크 실패 - 예상하지 못한 오류');
        }
      }

      // 업데이트가 있는 경우 알림 표시
      if (updateInfo && updateInfo.hasUpdate) {
        showUpdateNotification(updateInfo);
      } else if (updateInfo && updateInfo.error) {
        log(`버전 체크 오류: ${updateInfo.error}`);
      }

    } catch (error) {
      console.error('[버전체크] 초기화 오류:', error);
      log(`버전 체크 초기화 오류: ${error.message} (스택: ${error.stack})`);
    }
  }

  // 업데이트 알림 표시
  function showUpdateNotification(updateInfo) {
    const notification = document.getElementById('updateNotification');
    const versionElement = document.getElementById('updateVersion');
    const dateElement = document.getElementById('updateDate');
    const updateButton = document.getElementById('updateButton');
    const dismissButton = document.getElementById('updateDismiss');

    if (!notification || !versionElement || !dateElement || !updateButton || !dismissButton) {
      return;
    }

    // 버전 정보 표시
    versionElement.textContent = `${updateInfo.currentVersion} → ${updateInfo.latestVersion}`;
    
    // 출시 날짜 표시
    if (updateInfo.publishedAt) {
      const publishDate = new Date(updateInfo.publishedAt);
      dateElement.textContent = `${publishDate.toLocaleDateString('ko-KR')} 출시`;
    }

    // 업데이트 버튼 이벤트 - 강제 자동 업데이트 실행
    updateButton.onclick = async () => {
      try {
        log('🔄 자동 업데이트 시작...');
        updateButton.disabled = true;
        updateButton.textContent = '업데이트 중...';
        
        const versionChecker = new VersionChecker();
        
        // Chrome 제약을 우회한 강제 업데이트 실행
        const success = await versionChecker.forceDirectUpdate(updateInfo);
        
        if (success) {
          log('✅ 업데이트 완료!');
          log('📦 확장프로그램이 새 버전으로 업데이트되었습니다.');
          log('🔄 적용 방법:');
          log('1. 브라우저 완전 재시작 (모든 탭 닫고 다시 열기)');
          log('2. 확장프로그램 관리에서 이 앱을 껐다가 켜기');
          log('3. 페이지 새로고침하여 새 버전 확인');
          log('✅ 업데이트는 완료되었습니다. 위 방법 중 하나를 실행하세요.');
          
          // 업데이트 알림 숨기기
          notification.classList.add('hidden');
          
          // 자동 재시작 제거 - 사용자가 직접 실행하도록 안내
          
        } else {
          log('❌ 자동 업데이트 실패');
          log('🔄 해결 방법:');
          log('1. 브라우저 완전 재시작 (모든 탭 닫고 다시 열기)');
          log('2. 확장프로그램 관리에서 이 앱을 껐다가 켜기');
          log('3. 페이지 새로고침 후 업데이트 재시도');
          log('⚠️ 실패한 업데이트는 재시작하지 않습니다. 위 방법으로 해결 후 재시도하세요.');
        }
        
      } catch (error) {
        log(`❌ 업데이트 실패: ${error.message}`);
        log(`📋 오류 상세: ${error.stack || error}`);
        log('🔄 해결 방법:');
        log('1. 브라우저 완전 재시작 (모든 탭 닫고 다시 열기)');
        log('2. 확장프로그램 관리에서 이 앱을 껐다가 켜기');
        log('3. 페이지 새로고침 후 업데이트 재시도');
        log('⚠️ 실패한 업데이트는 재시작하지 않습니다. 위 방법으로 해결 후 재시도하세요.');
        updateButton.disabled = false;
        updateButton.textContent = '업데이트 받기';
      }
    };

    // 닫기 버튼 이벤트
    dismissButton.onclick = async () => {
      const versionChecker = new VersionChecker();
      await versionChecker.dismissUpdate();
      notification.classList.add('hidden');
      log('업데이트 알림을 무시했습니다.');
    };

    // 알림 표시
    notification.classList.remove('hidden');
    log(`업데이트 알림 표시: v${updateInfo.latestVersion} 사용 가능`);
  }


  // 버전 체커 초기화 (페이지 로드 후 실행)
  setTimeout(initVersionChecker, 500);
});