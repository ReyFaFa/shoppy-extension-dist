# Shoppy Chrome Extension - 자동 업데이트 시스템

중국어를 한국어로 번역하는 Chrome Extension with 완전 자동화된 업데이트 시스템.

## 🚀 자동 업데이트 시스템

### 📦 Extension 정보
- **Extension ID**: `paahaflndlkclhlpchlfngbpneeidodl` (고정)
- **Update URL**: `https://reyfafa.github.io/ShoppyDelight/update.xml`
- **배포**: GitHub Actions + GitHub Pages

### 🔄 업데이트 체인
```
GitHub Release → Actions → CRX Build → GitHub Pages → Chrome Auto-Update
```

## 🔧 개발자 설정 가이드

### 1. GitHub Secrets 설정

Extension 자동 빌드를 위해 개인키를 GitHub Secrets에 Base64 형태로 등록해야 합니다.

#### 자동 설정 (권장)
```bash
cd deploy
node scripts/setup-keys.js
```

#### 수동 설정
1. **GitHub Repository 설정**
   - Settings → Secrets and variables → Actions
   - New repository secret 클릭

2. **Secret 정보**
   - Name: `CRX_KEY_BASE64`
   - Value: Base64로 인코딩된 개인키 (단일 라인)

3. **Base64 키 생성 방법**
   ```bash
   # 개인키가 private.pem 파일에 있는 경우
   base64 -w0 private.pem > private-base64.txt

   # Windows에서는
   certutil -encode private.pem private-base64.txt
   ```

### 2. GitHub Pages 활성화

1. **Repository Settings** → **Pages**
2. **Source**: GitHub Actions 선택
3. **자동 배포 활성화**

### 3. Extension 배포

#### 릴리즈 생성으로 자동 배포
```bash
# 버전 태그와 manifest.json 버전이 일치해야 함
git tag v1.6.4
git push origin v1.6.4

# GitHub 릴리즈 생성
gh release create v1.6.4 --title "v1.6.4: New Features" --notes "릴리즈 노트"
```

#### 수동 워크플로 실행
```bash
gh workflow run "Deploy Chrome Extension" --field version=1.6.4
```

## 📋 검수 기준 (배포 성공 확인)

릴리즈 후 다음이 모두 확인되어야 자동 업데이트가 정상 작동합니다:

### ✅ GitHub Pages 배포 확인
- [ ] `https://reyfafa.github.io/ShoppyDelight/update.xml` 접근 가능
- [ ] `https://reyfafa.github.io/ShoppyDelight/shoppy-extension-{version}.crx` 다운로드 가능
- [ ] update.xml에서 Extension ID와 버전 정보 정확

### ✅ Chrome Extension 확인
- [ ] Extension ID가 `paahaflndlkclhlpchlfngbpneeidodl`로 고정
- [ ] manifest.json의 update_url이 올바름
- [ ] 자동 업데이트 감지 (수 분 내)

## 🛠️ 사용자 설치 가이드

### 최초 설치 방법

1. **CRX 파일 다운로드**
   - [Releases 페이지](https://github.com/ReyFaFa/ShoppyDelight/releases)에서 최신 `.crx` 파일 다운로드

2. **Chrome에 설치**
   - `chrome://extensions/` 페이지로 이동
   - "개발자 모드" 활성화
   - CRX 파일을 페이지에 드래그 앤 드롭
   - 설치 확인 후 완료

3. **자동 업데이트 확인**
   - 설치 후 Chrome이 자동으로 업데이트 체크
   - 새 버전 발견 시 자동 다운로드 및 설치
   - 사용자 개입 없이 최신 버전 유지

### 수동 업데이트 체크 (선택사항)
Extension에서 "업데이트 확인" 버튼 클릭 시 즉시 업데이트 체크 가능.

## 🔍 트러블슈팅

### GitHub Actions 실패 시
1. **CRX_KEY_BASE64 시크릿 확인**
   - Base64로 인코딩된 개인키인지 확인
   - 줄바꿈 없는 단일 라인인지 확인

2. **버전 일치 확인**
   - Git 태그와 manifest.json 버전이 일치하는지 확인
   - 시맨틱 버전 형식 (예: 1.6.4) 사용

3. **manifest.json 키 확인**
   - "key" 필드가 개인키와 일치하는지 확인
   - Extension ID가 고정되어 있는지 확인

### 자동 업데이트 안될 시
1. **GitHub Pages 상태 확인**
   - update.xml 파일이 배포되었는지 확인
   - CRX 파일이 다운로드 가능한지 확인

2. **Chrome Extension 상태 확인**
   - Extension ID가 변경되지 않았는지 확인
   - update_url이 올바른지 확인

3. **수동 업데이트 체크**
   - Extension 설정에서 "업데이트 확인" 실행
   - Chrome 재시작 후 확인

## 🏗️ 시스템 구조

### 배포 파일 구조
```
deploy/
├── scripts/
│   ├── setup-keys.js       # Extension 키 생성 및 설정
│   ├── build-crx.js        # CRX 파일 빌드 (레거시)
│   └── generate-update-xml.js # update.xml 생성 (레거시)
├── templates/
│   └── update.xml.template # update.xml 템플릿
├── key-info.json          # Extension 키 정보 (자동 생성)
└── package.json           # 의존성 관리
```

### GitHub Actions 워크플로
1. **버전 검증**: 태그와 manifest.json 일치 확인
2. **키 복원**: Base64 시크릿을 private.pem으로 변환
3. **CRX 빌드**: crx3로 Extension 패키징 및 서명
4. **update.xml 생성**: 템플릿으로 업데이트 매니페스트 생성
5. **GitHub Pages 배포**: 자동 배포 및 CDN 업데이트
6. **릴리즈 에셋**: CRX 파일을 릴리즈에 첨부

### 보안
- **개인키 보호**: GitHub Secrets로 암호화 저장
- **Extension ID 고정**: 공개키 기반 일관된 ID
- **서명 검증**: Chrome이 CRX 무결성 자동 검증
- **HTTPS 배포**: GitHub Pages를 통한 안전한 배포

## 📞 지원

- **Issues**: [GitHub Issues](https://github.com/ReyFaFa/ShoppyDelight/issues)
- **Releases**: [GitHub Releases](https://github.com/ReyFaFa/ShoppyDelight/releases)
- **배포 상태**: [GitHub Actions](https://github.com/ReyFaFa/ShoppyDelight/actions)