/**
 * Shoppy Extension Auth Popup Controller
 * 인증 상태 관리 및 UI 제어
 */

class AuthPopupController {
  constructor() {
    this.auth = window.shoppyAuth;
    this.elements = {};
    this.init();
  }

  /**
   * 초기화
   */
  async init() {
    this.bindElements();
    this.bindEvents();
    await this.updateUI();
  }

  /**
   * DOM 요소 바인딩
   */
  bindElements() {
    this.elements = {
      authStatus: document.getElementById('authStatus'),
      userInfo: document.getElementById('userInfo'),
      userName: document.getElementById('userName'),
      userEmail: document.getElementById('userEmail'),
      licenseExpiry: document.getElementById('licenseExpiry'),
      permissions: document.getElementById('permissions'),
      permissionList: document.getElementById('permissionList'),
      loading: document.getElementById('loading'),
      error: document.getElementById('error'),
      success: document.getElementById('success'),
      unauthenticatedView: document.getElementById('unauthenticatedView'),
      authenticatedView: document.getElementById('authenticatedView'),
      loginBtn: document.getElementById('loginBtn'),
      logoutBtn: document.getElementById('logoutBtn'),
      refreshTokenBtn: document.getElementById('refreshTokenBtn'),
      translateBtn: document.getElementById('translateBtn'),
      bulkTranslateBtn: document.getElementById('bulkTranslateBtn'),
      settingsBtn: document.getElementById('settingsBtn')
    };
  }

  /**
   * 이벤트 리스너 바인딩
   */
  bindEvents() {
    this.elements.loginBtn.addEventListener('click', () => this.handleLogin());
    this.elements.logoutBtn.addEventListener('click', () => this.handleLogout());
    this.elements.refreshTokenBtn.addEventListener('click', () => this.handleRefreshToken());
    this.elements.translateBtn.addEventListener('click', () => this.handleTranslate());
    this.elements.bulkTranslateBtn.addEventListener('click', () => this.handleBulkTranslate());
    this.elements.settingsBtn.addEventListener('click', () => this.handleSettings());
  }

  /**
   * UI 업데이트
   */
  async updateUI() {
    this.showLoading(true);

    try {
      const isAuthenticated = await this.auth.isAuthenticated();

      if (isAuthenticated) {
        await this.showAuthenticatedView();
      } else {
        this.showUnauthenticatedView();
      }
    } catch (error) {
      console.error('UI update error:', error);
      this.showError('UI 업데이트 중 오류가 발생했습니다.');
    } finally {
      this.showLoading(false);
    }
  }

  /**
   * 인증된 사용자 뷰 표시
   */
  async showAuthenticatedView() {
    try {
      const userInfo = await this.auth.getUserInfo();
      const token = await this.auth.getToken();

      // 토큰 파싱하여 권한 정보 추출
      let permissions = [];
      let expiryTime = null;

      if (token) {
        try {
          const payload = JSON.parse(atob(token.split('.')[1]));
          permissions = payload.permissions || [];
          expiryTime = payload.exp * 1000;
        } catch (e) {
          console.error('Token parsing error:', e);
        }
      }

      // 인증 상태 업데이트
      this.elements.authStatus.textContent = '✅ 인증됨';
      this.elements.authStatus.className = 'auth-status authenticated';

      // 사용자 정보 표시
      if (userInfo) {
        this.elements.userName.textContent = userInfo.name || 'Unknown User';
        this.elements.userEmail.textContent = userInfo.email || '';

        if (expiryTime) {
          const expiryDate = new Date(expiryTime);
          this.elements.licenseExpiry.textContent = `라이선스 만료: ${expiryDate.toLocaleDateString()}`;
        }

        this.elements.userInfo.style.display = 'block';
      }

      // 권한 정보 표시
      if (permissions.length > 0) {
        this.elements.permissionList.innerHTML = permissions
          .map(perm => `<span class="permission-item">${perm}</span>`)
          .join('');
        this.elements.permissions.style.display = 'block';
      }

      // 기능 버튼 권한에 따라 활성화/비활성화
      this.elements.translateBtn.disabled = !permissions.includes('translate');
      this.elements.bulkTranslateBtn.disabled = !permissions.includes('bulk_translate');

      // 뷰 전환
      this.elements.unauthenticatedView.style.display = 'none';
      this.elements.authenticatedView.style.display = 'block';

    } catch (error) {
      console.error('Authenticated view error:', error);
      this.showError('사용자 정보를 불러올 수 없습니다.');
    }
  }

  /**
   * 미인증 사용자 뷰 표시
   */
  showUnauthenticatedView() {
    this.elements.authStatus.textContent = '🔒 인증이 필요합니다';
    this.elements.authStatus.className = 'auth-status unauthenticated';

    this.elements.userInfo.style.display = 'none';
    this.elements.permissions.style.display = 'none';

    this.elements.unauthenticatedView.style.display = 'block';
    this.elements.authenticatedView.style.display = 'none';
  }

  /**
   * 로그인 처리
   */
  async handleLogin() {
    this.showLoading(true);
    this.hideMessages();

    try {
      await this.auth.startAuthentication();
      this.showSuccess('로그인이 완료되었습니다!');
      await this.updateUI();
    } catch (error) {
      console.error('Login error:', error);
      this.showError(`로그인 실패: ${error.message}`);
    } finally {
      this.showLoading(false);
    }
  }

  /**
   * 로그아웃 처리
   */
  async handleLogout() {
    this.showLoading(true);
    this.hideMessages();

    try {
      await this.auth.logout();
      this.showSuccess('로그아웃되었습니다.');
      await this.updateUI();
    } catch (error) {
      console.error('Logout error:', error);
      this.showError(`로그아웃 실패: ${error.message}`);
    } finally {
      this.showLoading(false);
    }
  }

  /**
   * 토큰 갱신 처리
   */
  async handleRefreshToken() {
    this.showLoading(true);
    this.hideMessages();

    try {
      await this.auth.refreshToken();
      this.showSuccess('토큰이 갱신되었습니다.');
      await this.updateUI();
    } catch (error) {
      console.error('Token refresh error:', error);
      this.showError(`토큰 갱신 실패: ${error.message}`);
    } finally {
      this.showLoading(false);
    }
  }

  /**
   * 번역 기능 실행
   */
  async handleTranslate() {
    try {
      await this.auth.withAuth(async () => {
        // 기존 번역 기능 실행
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: () => {
              // 기존 번역 스크립트 실행
              if (window.runTranslator) {
                window.runTranslator();
              } else {
                alert('번역 기능을 찾을 수 없습니다.');
              }
            }
          });
        });

        this.showSuccess('번역 기능이 실행되었습니다.');
        window.close(); // 팝업 닫기
      }, 'translate');

    } catch (error) {
      console.error('Translate error:', error);
      this.showError(`번역 실행 실패: ${error.message}`);

      if (error.message.includes('Authentication required')) {
        await this.auth.showAuthRequired();
      } else if (error.message.includes('Permission required')) {
        await this.auth.showPermissionDenied('translate');
      }
    }
  }

  /**
   * 대량 번역 기능 실행
   */
  async handleBulkTranslate() {
    try {
      await this.auth.withAuth(async () => {
        // 기존 대량 번역 기능 실행
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: () => {
              if (window.runBulkTranslator) {
                window.runBulkTranslator();
              } else {
                alert('대량 번역 기능을 찾을 수 없습니다.');
              }
            }
          });
        });

        this.showSuccess('대량 번역 기능이 실행되었습니다.');
        window.close();
      }, 'bulk_translate');

    } catch (error) {
      console.error('Bulk translate error:', error);
      this.showError(`대량 번역 실행 실패: ${error.message}`);

      if (error.message.includes('Authentication required')) {
        await this.auth.showAuthRequired();
      } else if (error.message.includes('Permission required')) {
        await this.auth.showPermissionDenied('bulk_translate');
      }
    }
  }

  /**
   * 설정 페이지 열기
   */
  async handleSettings() {
    try {
      chrome.runtime.openOptionsPage();
      window.close();
    } catch (error) {
      console.error('Settings error:', error);
      this.showError('설정 페이지를 열 수 없습니다.');
    }
  }

  /**
   * 로딩 표시/숨김
   */
  showLoading(show) {
    this.elements.loading.style.display = show ? 'block' : 'none';

    // 버튼들 비활성화
    const buttons = document.querySelectorAll('.btn, .feature-btn');
    buttons.forEach(btn => {
      btn.disabled = show;
    });
  }

  /**
   * 오류 메시지 표시
   */
  showError(message) {
    this.elements.error.textContent = message;
    this.elements.error.style.display = 'block';
    this.elements.success.style.display = 'none';
  }

  /**
   * 성공 메시지 표시
   */
  showSuccess(message) {
    this.elements.success.textContent = message;
    this.elements.success.style.display = 'block';
    this.elements.error.style.display = 'none';
  }

  /**
   * 메시지 숨김
   */
  hideMessages() {
    this.elements.error.style.display = 'none';
    this.elements.success.style.display = 'none';
  }
}

// 팝업 로드 시 컨트롤러 초기화
document.addEventListener('DOMContentLoaded', () => {
  new AuthPopupController();
});