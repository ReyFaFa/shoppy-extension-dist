// GPT 옵션명 번역 버튼 - 사용자 테스트 검증된 버전
(() => {
  // 중복 실행 방지
  if (window.__GPT_OPTION_TRANSLATE_LOADED__) {
    console.log('🔄 [GPT번역] 이미 로드됨, 스킵');
    return;
  }
  window.__GPT_OPTION_TRANSLATE_LOADED__ = true;

  // 고유 마커 (중복 삽입 방지)
  const ROW_MARK_ATTR = 'data-pt-gpt-opt-btn-row';
  const BTN_ATTR = 'data-pt';
  const BTN_ATTR_VAL = 'gpt-option-translate';

  // "원본 옵션명" 버튼이 들어있는 행(툴바) 찾기
  const findToolbarRow = () => {
    // 퍼센티 쪽 툴바 그리드 형태 (클래스 구조 유지)
    const rows = document.querySelectorAll('div.ant-row.ant-row-end.ant-row-middle.css-1li46mu');
    for (const row of rows) {
      // 이 행 안에 "원본 옵션명" 텍스트 가진 버튼이 있는지 확인
      const hasOriginBtn = Array.from(row.querySelectorAll('button span'))
        .some(s => s.textContent.trim() === '원본 옵션명');
      if (hasOriginBtn) return row;
    }
    return null;
  };

  // 버튼 삽입 로직 (조건 불만족/중복이면 false)
  const insertButtonIfReady = () => {
    const toolbarRow = findToolbarRow();
    if (!toolbarRow) return false;                          // "원본 옵션명" 안 보이면 미삽입
    if (toolbarRow.hasAttribute(ROW_MARK_ATTR)) return true; // 이미 처리됨
    if (toolbarRow.querySelector(`button[${BTN_ATTR}="${BTN_ATTR_VAL}"]`)) {
      toolbarRow.setAttribute(ROW_MARK_ATTR, '1');
      return true;
    }

    // 버튼 DOM 생성 (안트 디자인 클래스 맞춤)
    const col = document.createElement('div');
    col.className = 'ant-col css-1li46mu';
    col.style.cssText = 'padding-left: 4px; padding-right: 4px;';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'ant-btn css-1li46mu ant-btn-default';
    btn.setAttribute(BTN_ATTR, BTN_ATTR_VAL);
    btn.innerHTML = '<span>GPT AI 번역</span>';
    
    // 버튼 색상 설정 (블루 배경, 화이트 글씨)
    btn.style.cssText = `
      background-color: #1890ff !important;
      border-color: #1890ff !important;
      color: white !important;
    `;

    // 클릭 핸들러: 팝업을 열지 않고 백그라운드에서 직접 번역 실행
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      console.log('🚀 [GPT번역] 옵션명 번역 실행 (백그라운드 직접 실행)');
      
      // 버튼 상태 변경
      btn.disabled = true;
      btn.innerHTML = '<span>번역 중...</span>';
      
      try {
        // Chrome runtime 존재 여부 확인
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
          throw new Error('Chrome extension runtime이 준비되지 않았습니다. 페이지를 새로고침해주세요.');
        }

        // 팝업을 열지 않고 백그라운드에서 직접 번역 실행
        chrome.runtime.sendMessage({
          action: 'executePopupTranslation'
        }, (response) => {
          // Extension context가 무효화되었는지 확인
          if (!chrome.runtime) {
            console.log('🔄 [GPT번역] Chrome runtime이 무효화됨, 페이지 새로고침 필요');
            btn.innerHTML = '<span>페이지 새로고침 필요</span>';
            setTimeout(() => window.location.reload(), 2000);
            return;
          }
          
          if (chrome.runtime.lastError) {
            const errorMessage = chrome.runtime.lastError.message;
            if (errorMessage.includes('Extension context invalidated')) {
              console.log('🔄 [GPT번역] 확장프로그램이 재로드됨, 페이지 새로고침 필요');
              btn.innerHTML = '<span>페이지 새로고침 필요</span>';
              setTimeout(() => {
                window.location.reload();
              }, 2000);
              return;
            }
            throw new Error(errorMessage);
          }
          
          if (response && response.success) {
            console.log('✅ [GPT번역] 백그라운드 번역 완료');
            btn.innerHTML = '<span>✅ 완료</span>';
            setTimeout(() => {
              btn.innerHTML = '<span>GPT AI 번역</span>';
              btn.disabled = false;
            }, 2000);
          } else {
            throw new Error(response?.error || '번역 실행 실패');
          }
        });
        
      } catch (error) {
        console.error('❌ [GPT번역] 오류:', error.message);
        console.error('❌ [GPT번역] 오류 스택:', error.stack);
        console.log('❌ [GPT번역] Chrome runtime 상태:', typeof chrome !== 'undefined' ? !!chrome.runtime : 'chrome 객체 없음');
        btn.innerHTML = '<span>❌ 오류</span>';
        setTimeout(() => {
          btn.innerHTML = '<span>GPT AI 번역</span>';  
          btn.disabled = false;
        }, 3000);
      }
    });

    // "원본 옵션명" 앞(맨 앞)으로 삽입
    toolbarRow.insertBefore(col, toolbarRow.firstElementChild);
    col.appendChild(btn);

    // 중복 방지 마킹
    toolbarRow.setAttribute(ROW_MARK_ATTR, '1');

    console.log('✅ [GPT번역] 버튼 삽입 완료:', toolbarRow);
    return true;
  };

  // 즉시 한 번 시도
  insertButtonIfReady();

  // 지속적으로 DOM 변경 감시 (페이지 이동, 상품 변경 대응)
  const obs = new MutationObserver(() => {
    insertButtonIfReady();
  });
  obs.observe(document.body, { childList: true, subtree: true });

  console.log('✅ [GPT번역] MutationObserver 시작 - 지속적 감시 모드');
})();