// 전체 이미지 번역 기능 모듈 - 안정적인 썸네일 래퍼 + 빠른 완료 감지
(() => {
  const CFG = {
    TITLE_TEXT: '퍼센티 이미지 에디터',
    OUR_BTN_ID: 'p-translate-all-btn',
    OUR_STYLE_ID: 'p-translate-all-style',
    ONECLICK_TEXT: '원클릭 이미지 번역',
    SMALL_TRANSLATE_ROW_ANCHOR: '번역하기',

    // ✅ 썸네일 "이미지"를 기준으로 래퍼를 찾아 클릭 (삭제 아이콘 버튼 아님!)
    THUMB_IMG_SEL: 'img.p_tooltip_image_editor_thumb',

    // 스피너/로딩
    LOADING_CLASS: 'ant-btn-loading',

    // 네트워크 완료 패턴 (클릭 이후에만 카운트)
    NETWORK_DONE_REGEX: /^(blob:|https?:\/\/.*\/image.*translate|https?:\/\/.*\/files\/)/i,

    STEP_DELAY: 500,
    WAIT_TIMEOUT: 30000,
  };

  // 유틸리티 함수들
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const debounce = (fn, ms=150) => { let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a), ms); }; };

  // 성능 최적화를 위한 로깅 레벨 관리
  const LogLevel = {
    ERROR: 0,
    WARN: 1,
    INFO: 2,
    DEBUG: 3
  };

  const currentLogLevel = LogLevel.INFO; // 기본 로그 레벨

  const log = {
    error: (...args) => currentLogLevel >= LogLevel.ERROR && console.error(...args),
    warn: (...args) => currentLogLevel >= LogLevel.WARN && console.warn(...args),
    info: (...args) => currentLogLevel >= LogLevel.INFO && console.log(...args),
    debug: (...args) => currentLogLevel >= LogLevel.DEBUG && console.log(...args)
  };

  const allDocs = () => {
    const docs = [document];
    for (const f of document.querySelectorAll('iframe,frame')) {
      try { if (f.contentDocument) docs.push(f.contentDocument); } catch {}
    }
    return docs;
  };

  // 성능 최적화된 DOM 셰렉터 헬퍼
  const q = (sel, root=document) => root.querySelector(sel);
  const qa = (sel, root=document) => Array.from(root.querySelectorAll(sel));

  // 캐시된 셀렉터 결과를 위한 메모이제이션
  const memoizedSelectors = new Map();
  const memoQuery = (sel, root=document, ttl=5000) => {
    const key = `${sel}_${root.nodeName || 'document'}`;
    const cached = memoizedSelectors.get(key);

    if (cached && Date.now() - cached.timestamp < ttl) {
      return cached.result;
    }

    const result = root.querySelector(sel);
    memoizedSelectors.set(key, { result, timestamp: Date.now() });

    // TTL 기반 캐시 정리
    setTimeout(() => memoizedSelectors.delete(key), ttl);

    return result;
  };

  const findByText = (doc, text) => {
    for (const el of doc.querySelectorAll('div,button,span,h1,h2,h3')) {
      if ((el.textContent||'').trim() === text) return el;
    }
    return null;
  };

  const findOneClickButton = (doc) =>
    [...doc.querySelectorAll('button')].find(b => (b.textContent||'').includes(CFG.ONECLICK_TEXT)) || null;

  const findSmallTranslateRow = (doc) => {
    const anchorBtn = [...doc.querySelectorAll('button')].find(b => (b.textContent||'').includes(CFG.SMALL_TRANSLATE_ROW_ANCHOR));
    return anchorBtn ? anchorBtn.parentElement : null;
  };

  // ---------- 썸네일 IMG → 클릭 가능한 래퍼 얻기 ----------
  function resolveClickableFromThumb(img) {
    // 보통 IMG의 부모/조상 중 클릭이 걸린 래퍼가 있음. (삭제 아이콘은 제외)
    // 우선순위: 버튼/드래그 래퍼/스팬 → 마지막엔 IMG 자체 클릭
    const bad = (el) => el && el.matches('button.ant-btn-icon-only, .ant-btn-icon-only');
    let el = img;
    for (let i=0;i<4 && el;i++) {
      // 삭제 아이콘 버튼이 아니고, 크기가 있고, 클릭 가능해 보이는 요소면 사용
      if (!bad(el) && el instanceof HTMLElement && el.offsetWidth && el.offsetHeight) {
        // 실제 클릭 타겟인지 확인: 이미지 바로 위에 스팬/디브 래퍼가 대부분
        if (/^(SPAN|DIV|BUTTON)$/i.test(el.tagName)) break;
      }
      el = el.parentElement;
    }
    return el || img;
  }

  // ---------- 스피너 class 감시 ----------
  function waitClass(el, className, want=true, timeout=CFG.WAIT_TIMEOUT) {
    return new Promise((resolve, reject) => {
      if (!el) return reject(new Error('target null'));
      const ok = () => (!!el.classList.contains(className)) === want;
      if (ok()) return resolve();
      const mo = new MutationObserver(() => { if (ok()) { mo.disconnect(); resolve(); } });
      mo.observe(el, { attributes:true, attributeFilter:['class'] });
      const to = setTimeout(() => { mo.disconnect(); reject(new Error('waitClass timeout')); }, timeout);
      // 정리
      const done = () => { clearTimeout(to); mo.disconnect(); };
      resolve._cleanup = done;
      reject._cleanup = done;
    });
  }

  // ---------- 네트워크(blob/translate) + 스피너 사이클 ----------
  function waitForTranslateDone(btn, clickTs, timeoutMs=CFG.WAIT_TIMEOUT) {
    return new Promise((resolve, reject) => {
      let netSeen = false;
      let settled = false;

      const origXHROpen = XMLHttpRequest.prototype.open;
      const origFetch = window.fetch;

      const finish = async () => {
        if (settled) return;
        settled = true;
        try { await sleep(300); } finally {
          cleanup();
          resolve();
        }
      };

      function patch() {
        XMLHttpRequest.prototype.open = function(method, url){
          try {
            const onload = () => {
              try {
                const u = this.responseURL || url || '';
                if (Date.now() >= clickTs && CFG.NETWORK_DONE_REGEX.test(u)) {
                  netSeen = true;
                }
              } catch {}
            };
            this.addEventListener('load', onload, { once:false });
          } catch {}
          return origXHROpen.apply(this, arguments);
        };

        window.fetch = async function(){
          const res = await origFetch.apply(this, arguments);
          try {
            const u = res.url || '';
            if (Date.now() >= clickTs && CFG.NETWORK_DONE_REGEX.test(u)) {
              netSeen = true;
            }
          } catch {}
          return res;
        };
      }

      function unpatch() {
        XMLHttpRequest.prototype.open = origXHROpen;
        window.fetch = origFetch;
      }

      const to = setTimeout(() => {
        cleanup();
        reject(new Error('translate timeout'));
      }, timeoutMs);

      const cleanup = () => {
        clearTimeout(to);
        try { unpatch(); } catch {}
        try { startMO.disconnect(); } catch {}
        try { endMO.disconnect(); } catch {}
      };

      // 1) 스피너 시작 기다림 (최대 8초까지만)
      const startMO = new MutationObserver(() => {});
      const endMO = new MutationObserver(() => {});
      const waitStart = waitClass(btn, CFG.LOADING_CLASS, true, 8000).catch(()=>{});
      // 2) 스피너 종료 기다림
      const waitEnd = (async () => {
        try { await waitStart; } catch {}
        await waitClass(btn, CFG.LOADING_CLASS, false, timeoutMs);
      })();

      // 3) 네트워크 패치
      patch();

      // 4) 둘 다 완료되면 종료
      (async () => {
        try {
          await waitEnd;
          // 네트워크 신호가 없더라도 스피너 사이클이 끝났으면 진행(실서버에서 blob이 안 찍히는 케이스 방지)
          // 다만 보이면 조금 더 빨리 지나가도록
          await sleep(netSeen ? 150 : 300);
          finish();
        } catch(e) {
          cleanup();
          reject(e);
        }
      })();
    });
  }

  async function clickCenter(el) {
    if (!(el instanceof HTMLElement)) { el.click(); return; }
    el.scrollIntoView({ block: 'center', inline: 'center' });
    await sleep(80);
    const r = el.getBoundingClientRect();
    const x = r.left + r.width/2;
    const y = r.top + r.height/2;
    const target = document.elementFromPoint(x, y);
    // 삭제 아이콘을 밟으면 안 됨
    if (target && target.closest && target.closest('.ant-btn-icon-only')) {
      // 중앙에서 약간 왼쪽으로 오프셋
      const nx = Math.max(r.left + 10, r.left + r.width/2 - 20);
      const ny = r.top + r.height/2;
      const t2 = document.elementFromPoint(nx, ny) || el;
      t2.dispatchEvent(new MouseEvent('click', { bubbles:true, cancelable:true, view:window, clientX:nx, clientY:ny }));
    } else {
      (target || el).dispatchEvent(new MouseEvent('click', { bubbles:true, cancelable:true, view:window, clientX:x, clientY:y }));
    }
  }

  async function clickWithRetry(el, label='click', retries=3) {
    for (let i=0;i<=retries;i++){
      try {
        await clickCenter(el);
        log.info(`[전체 번역] ${label} 클릭`);
        return;
      } catch(e){
        if (i===retries) throw e;
        await sleep(120);
      }
    }
  }

  // ---------- 스타일 & 버튼 ----------
  const ensureStyle = (doc) => {
    if (doc.getElementById(CFG.OUR_STYLE_ID)) return;
    const st = doc.createElement('style');
    st.id = CFG.OUR_STYLE_ID;
    st.textContent = `
      @keyframes pspin { to { transform: rotate(360deg); } }
      .p-spin { display:inline-block; width:14px; height:14px; margin-left:8px;
        border:2px solid currentColor; border-right-color:transparent; border-radius:50%;
        animation: pspin .6s linear infinite; vertical-align:-2px; opacity:.9; }
      #${CFG.OUR_BTN_ID}{ display:block; width:100%; }
    `;
    (doc.head||doc.documentElement).appendChild(st);
  };

  const buildButton = (doc) => {
    const btn = doc.createElement('button');
    btn.id = CFG.OUR_BTN_ID;
    btn.type = 'button';
    btn.className = 'ant-btn ant-btn-default css-1li46mu';
    btn.innerHTML = `
      <span class="ant-btn-icon">
        <span role="img" aria-label="thunderbolt" class="anticon anticon-thunderbolt">
          <svg viewBox="64 64 896 896" width="1em" height="1em" fill="currentColor" aria-hidden="true">
            <path d="M848 359.3H627.7L825.8 109c4.1-5.3.4-13-6.3-13H436c-2.8 0-5.5 1.5-6.9 4L170 547.5c-3.1 5.3.7 12 6.9 12h174.4l-89.4 357.6c-1.9 7.8 7.5 13.3 13.3 7.7L853.5 373c5.2-4.9 1.7-13.7-5.5-13.7zM378.2 732.5l60.3-241H281.1l189.6-327.4h224.6L487 427.4h211L378.2 732.5z"/>
          </svg>
        </span>
      </span>
      <span>전체 이미지 번역</span>
      <i class="p-spin" style="display:none"></i>
    `;
    
    // 버튼 색상 설정 (블루 배경, 화이트 글씨)
    btn.style.cssText = `
      background-color: #1890ff !important;
      border-color: #1890ff !important;
      color: white !important;
      width: 100%;
    `;
    btn.addEventListener('click', () => {
      if (window.P_TRANSLATE?.running) {
        window.P_TRANSLATE.stop();
        return;
      }
      window.P_TRANSLATE?.runAll();
    });
    return btn;
  };

  const insertButtonIfNeeded = (doc) => {
    if (!findByText(doc, CFG.TITLE_TEXT)) return false;
    if (doc.getElementById(CFG.OUR_BTN_ID)) return true;

    ensureStyle(doc);

    const translateBtnRow = findSmallTranslateRow(doc);
    if (!translateBtnRow) return false;

    // 기존 "번역하기" 줄 바로 아래로 새 줄 하나 만들어서 버튼 추가
    const newRow = doc.createElement('div');
    newRow.style.display = 'block';
    newRow.style.marginTop = '8px';
    newRow.style.width = '100%';

    const ourBtn = buildButton(doc);

    const sampleBtn = translateBtnRow.querySelector('button');
    if (sampleBtn) {
      ourBtn.style.width = '100%';
      ourBtn.style.height = getComputedStyle(sampleBtn).height;
    }

    newRow.appendChild(ourBtn);
    translateBtnRow.insertAdjacentElement('afterend', newRow);
    return true;
  };

  // ---------- 전체 루프 ----------
  function getThumbClickableList(doc) {
    const imgs = qa(CFG.THUMB_IMG_SEL, doc);
    return imgs.map(img => resolveClickableFromThumb(img));
  }

  async function runAllThumbnails() {
    const doc = allDocs().find(d => findByText(d, CFG.TITLE_TEXT));
    if (!doc) {
      log.warn('[전체 번역] 에디터 페이지를 찾지 못했습니다.');
      return;
    }

    let items = getThumbClickableList(doc);
    if (!items.length) {
      log.warn('[전체 번역] 썸네일을 찾지 못했습니다.');
      return;
    }
    log.info(`[전체 번역] 썸네일 ${items.length}개 처리 시작`);

    for (let idx = 0; idx < items.length; idx++) {
      // 리렌더 대비: 매회 최신 목록으로 갱신
      items = getThumbClickableList(doc);
      const item = items[idx];
      if (!item) continue;

      // 1) 썸네일 선택
      await clickWithRetry(item, `thumb[${idx}]`);
      await sleep(250);

      // 2) 원클릭 번역 버튼
      const btn = findOneClickButton(doc);
      if (!btn) {
        log.warn('[전체 번역] 원클릭 이미지 번역 버튼을 찾지 못함');
        return;
      }
      await sleep(CFG.STEP_DELAY);
      const clickTs = Date.now();
      await clickWithRetry(btn, '원클릭 이미지 번역');

      // 3) 완료 대기 (스피너 사이클 + 네트워크)
      try {
        await waitForTranslateDone(btn, clickTs, CFG.WAIT_TIMEOUT);
      } catch(e){
        log.warn('[전체 번역] 완료 대기 타임아웃:', e?.message);
      }

      // 4) 다음으로
      await sleep(200);
    }

    log.info('[전체 번역] 썸네일 루프 완료');
  }

  // ---------- 전역 컨트롤 ----------
  window.P_TRANSLATE = {
    running: false,
    _stop: false,
    stop() { this._stop = true; this.running = false; },
    async runAll() {
      if (this.running) return;
      const doc = allDocs().find(d => findByText(d, CFG.TITLE_TEXT));
      if (!doc) return;

      const ourBtn = doc.getElementById(CFG.OUR_BTN_ID);
      const spin = ourBtn?.querySelector('.p-spin');
      const show = v => { if (spin) spin.style.display = v ? 'inline-block' : 'none'; };

      this.running = true; this._stop = false; show(true);
      try {
        await runAllThumbnails();
      } finally {
        show(false);
        this.running = false;
        this._stop = false;
        console.log('[전체 번역] 완료');
      }
    }
  };

  // ---------- 삽입 감시 ----------
  const watchDoc = (doc) => {
    const key='__p_watch__'; if (doc[key]) return; doc[key]=true;
    const tryInsert = debounce(()=>insertButtonIfNeeded(doc), 120);
    tryInsert();

    const mo = new MutationObserver(() => {
      if (findByText(doc, CFG.TITLE_TEXT)) tryInsert();
      else doc.getElementById(CFG.OUR_BTN_ID)?.remove();
    });
    mo.observe(doc.documentElement||doc, {childList:true, subtree:true});
    doc.defaultView?.addEventListener('unload', ()=>mo.disconnect(), {once:true});
  };

  const recheck = debounce(()=>allDocs().forEach(watchDoc), 150);
  ['pushState','replaceState'].forEach(m=>{
    const orig=history[m]; if(!orig||orig.__p_wrapped__) return;
    history[m]=function(...a){ const r=orig.apply(this,a); recheck(); return r; };
    history[m].__p_wrapped__=true;
  });
  window.addEventListener('popstate', recheck);
  document.addEventListener('visibilitychange', recheck);
  recheck();
})();

// 전체리스트 번역 버튼 추가
const section = Array.from(document.querySelectorAll("div"))
    .find(el => el.innerText && el.innerText.includes("수집 상품 목록"));

if (section) {
    const ellipsisBtn = Array.from(section.querySelectorAll("button"))
        .find(btn => btn.querySelector("svg[data-icon='ellipsis']"));
    if (ellipsisBtn) {
        if (!document.querySelector("#translateAllBtn")) {
            const newBtn = document.createElement("button");
            newBtn.id = "translateAllBtn";
            newBtn.type = "button";
            // ✅ 클래스는 직접 지정 (icon-only 제거)
            // 👇 그룹 지정 버튼과 동일한 클래스 세트
            newBtn.className = "ant-btn css-1li46mu ant-btn-default";

            // 색상만 강조 (antd 프라이머리 느낌)
            newBtn.style.marginLeft = "8px";
            newBtn.style.backgroundColor = "#1890ff";
            newBtn.style.borderColor = "#1890ff";
            newBtn.style.color = "white";

            newBtn.innerHTML = `
            <span class="ant-btn-icon">
                <span role="img" aria-label="thunderbolt" class="anticon anticon-thunderbolt">
                <svg viewBox="64 64 896 896" width="1em" height="1em" fill="currentColor" aria-hidden="true">
                    <path d="M848 359.3H627.7L825.8 109c4.1-5.3.4-13-6.3-13H436c-2.8 0-5.5 1.5-6.9 4L170 547.5c-3.1 5.3.7 12 6.9 12h174.4l-89.4 357.6c-1.9 7.8 7.5 13.3 13.3 7.7L853.5 373c5.2-4.9 1.7-13.7-5.5-13.7zM378.2 732.5l60.3-241H281.1l189.6-327.4h224.6L487 427.4h211L378.2 732.5z"/>
                </svg>
                </span>
            </span>
            <span>전체리스트 번역</span>
            `;
            newBtn.addEventListener("click", () => {
                document.body.setAttribute("translate-all", "true");
                console.log("✅ 전체리스트 번역 버튼 클릭됨!");
                processCheckedItems();
            });

            ellipsisBtn.parentNode.insertBefore(newBtn, ellipsisBtn.nextSibling);
            console.log("🎉 전체리스트 번역 버튼 추가 완료 (ellipsis 옆)");
        }
    }
}


// 체크된 상품 처리 함수
function processCheckedItems() {
    try {
        console.log("✅ 번역 버튼 클릭 감지됨 → 체크된 상품 수정 시작");

        const rows = document.querySelectorAll("li.ant-list-item");
        let clicked = false;

        rows.forEach((li, index) => {
            const idx = index + 1;
            try {
                const checkbox = li.querySelector("input.ant-checkbox-input");
                const isChecked = checkbox && (checkbox.checked || checkbox.getAttribute("checked") !== null);

                if (isChecked) {
                    console.log(`Row ${idx}: ✅ 체크됨 → 대상 상품`);

                    // XPath 대신 querySelector 사용
                    const detailBtn = Array.from(li.querySelectorAll("button"))
                        .find(btn => {
                            const span = btn.querySelector("span");
                            return span && span.textContent.includes("세부사항 수정 및 업로드");
                        });

                    if (detailBtn && !clicked) {
                        // 스크롤하여 버튼이 보이도록 조정
                        detailBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });

                        // 잠시 후 클릭
                        setTimeout(() => {
                            detailBtn.click();
                            console.log("👉 '세부사항 수정 및 업로드' 버튼 클릭 완료");

                            // "세부사항 수정 및 업로드" 버튼 클릭 후 "옵션" 탭 클릭
                            setTimeout(() => {
                                clickOptionTab();
                            }, 1000);
                        }, 500);

                        clicked = true;
                        return; // forEach에서 빠져나가기 위해 return 사용
                    }
                } else {
                    console.log(`Row ${idx}: ❌ 체크 안 됨 → 스킵`);
                }

            } catch (e) {
                console.log(`Row ${idx}: ⚠️ 처리 중 오류 발생 → ${e}`);
            }
        });

        if (!clicked) {
            console.log("⚠️ 체크된 상품이 없음");
        }

        // 다시 눌러도 동작 가능하도록 flag 초기화
        setTimeout(() => {
            document.body.removeAttribute('translate-all');
        }, 1000);

    } catch (error) {
        console.error("전체리스트 번역 처리 중 오류:", error);
        // 오류 발생 시에도 flag 초기화
        document.body.removeAttribute('translate-all');
    }
}

// "옵션" 탭 클릭 함수
function clickOptionTab() {
    try {
        console.log("🔍 '옵션' 탭 찾는 중...");

        // "옵션" 탭을 찾기 위한 여러 시도 (최대 10초)
        let attempts = 0;
        const maxAttempts = 20; // 0.5초 * 20 = 10초

        const findAndClickOption = () => {
            // span 요소 중에서 "옵션" 텍스트를 포함하는 것을 찾기
            const optionSpans = Array.from(document.querySelectorAll("span"))
                .filter(span => span.textContent && span.textContent.trim() === "옵션");

            if (optionSpans.length > 0) {
                const optionTab = optionSpans[0];

                // 화면에 보이도록 스크롤
                optionTab.scrollIntoView({ behavior: 'smooth', block: 'center' });

                setTimeout(() => {
                    // 클릭 실행
                    optionTab.click();
                    console.log("✅ '옵션' 탭 클릭 완료");

                    // "옵션" 탭 클릭 후 편집 버튼 클릭
                    setTimeout(() => {
                        clickEditButton();
                    }, 1500);
                }, 500);

                return true;
            }

            return false;
        };

        // 첫 번째 시도
        if (findAndClickOption()) {
            return;
        }

        // 주기적으로 재시도 (요소가 동적으로 로드될 수 있음)
        const retryInterval = setInterval(() => {
            attempts++;

            if (findAndClickOption()) {
                clearInterval(retryInterval);
                return;
            }

            if (attempts >= maxAttempts) {
                clearInterval(retryInterval);
                console.log("⚠️ '옵션' 탭을 찾을 수 없음 (10초 타임아웃)");
            }
        }, 500);

    } catch (error) {
        console.error("⚠️ '옵션' 탭 클릭 실패:", error);
    }
}

// "편집" 버튼 클릭 함수 - 최적화된 로깅
function clickEditButton() {
    try {
        console.log("🔍 '편집' 버튼 찾는 중...");

        // 옵션 리스트 전체 가져오기
        const optionRows = document.querySelectorAll("li.ant-list-item");

        if (optionRows.length === 0) {
            console.log("⚠️ 옵션 리스트를 찾을 수 없음");
            return;
        }

        console.log(`📋 총 ${optionRows.length}개 옵션 행 스캔 중...`);
        let foundEditButton = false;
        let scannedCount = 0;

        for (let idx = 0; idx < optionRows.length; idx++) {
            const row = optionRows[idx];
            const rowIndex = idx + 1;
            scannedCount++;

            try {
                // "편집" 텍스트를 포함하는 span 요소 찾기 (row 안에서만)
                const editSpans = Array.from(row.querySelectorAll("span"))
                    .filter(span => span.textContent && span.textContent.trim() === "편집");

                if (editSpans.length > 0) {
                    // 첫 번째 편집 버튼 클릭
                    const editButton = editSpans[0];

                    // 화면에 보이도록 스크롤
                    editButton.scrollIntoView({ behavior: 'smooth', block: 'center' });

                    setTimeout(() => {
                        editButton.click();
                        console.log(`✅ Row ${rowIndex}: '편집' 버튼 클릭 완료 (${scannedCount}/${optionRows.length} 스캔됨)`);

                        // 편집 버튼 클릭 후 전체 이미지 번역 버튼 클릭
                        setTimeout(() => {
                            clickImageTranslateButton();
                        }, 2000);
                    }, 500);

                    foundEditButton = true;
                    break; // 첫 번째만 클릭하고 종료
                }
                // 편집 버튼이 없는 경우 로그를 생략하여 콘솔 노이즈 감소

            } catch (error) {
                console.warn(`Row ${rowIndex}: ⚠️ 처리 중 오류 발생 → ${error}`);
            }
        }

        if (!foundEditButton) {
            console.log(`⚠️ '편집' 버튼을 찾을 수 없음 (${optionRows.length}개 행 스캔 완료) → 썸네일 탭으로 진행`);

            // 편집할 이미지가 없는 경우 바로 썸네일 탭으로 진행
            setTimeout(() => {
                clickThumbnailTab();
            }, 1000);
        }

    } catch (error) {
        console.error("⚠️ 옵션 리스트 탐색 실패:", error);

        // 오류 발생 시에도 썸네일 탭으로 진행
        setTimeout(() => {
            clickThumbnailTab();
        }, 1000);
    }
}

// 버튼 안정성을 위한 재사용 가능한 함수
function waitForButtonAndClick(buttonId, onSuccess, maxRetries = 10, delay = 500) {
    const button = document.getElementById(buttonId);
    if (button) {
        console.log(`✅ '${buttonId}' 버튼 발견!`);
        // 0.5초 지연 후 안전하게 클릭
        setTimeout(() => onSuccess(button), 500);
    } else if (maxRetries > 0) {
        console.log(`🔍 '${buttonId}' 버튼 재시도 중... (${maxRetries}회 남음)`);
        setTimeout(() => waitForButtonAndClick(buttonId, onSuccess, maxRetries - 1, delay), delay);
    } else {
        console.warn(`⚠️ '${buttonId}' 버튼을 찾을 수 없음 (최대 재시도 완료)`);
    }
}

// 전체 이미지 번역 버튼 클릭 및 완료 대기 함수
function clickImageTranslateButton() {
    try {
        console.log("🔍 '전체 이미지 번역' 버튼 찾는 중...");

        // 개선된 버튼 탐지 및 클릭 로직 사용
        waitForButtonAndClick('p-translate-all-btn', (button) => {
            // 화면에 보이도록 스크롤
            button.scrollIntoView({ behavior: 'smooth', block: 'center' });

            // 버튼 클릭
            button.click();
            console.log("👉 '전체 이미지 번역' 버튼 클릭 완료");

            // 번역 완료 대기 (기본 로직 사용)
            waitForTranslationComplete();
        });

    } catch (error) {
        console.error("⚠️ '전체 이미지 번역' 버튼 클릭 실패:", error);
    }
}

// 번역 완료 대기 및 저장 버튼 클릭 함수
function waitForTranslationComplete() {
    try {
        console.log("⏳ 이미지 번역 완료 대기 중...");

        const checkTranslationStatus = () => {
            // P_TRANSLATE 객체와 running 상태 확인
            if (window.P_TRANSLATE && !window.P_TRANSLATE.running) {
                console.log("✅ 이미지 번역 완료 감지!");

                // 번역 완료 후 저장 버튼 클릭 (이미지 저장 완료 대기 위해 딜레이 증가)
                setTimeout(() => {
                    clickSaveButton();
                }, 2000);

                return;
            }

            // 스피너 확인 (추가적인 완료 신호)
            const spinnerElement = document.querySelector('#p-translate-all-btn .p-spin');
            if (spinnerElement && spinnerElement.style.display === 'none') {
                console.log("✅ 스피너 숨김 확인 - 번역 완료!");

                setTimeout(() => {
                    clickSaveButton();
                }, 2000);

                return;
            }

            // 1초 후 재확인
            setTimeout(checkTranslationStatus, 1000);
        };

        // 번역 상태 확인 시작
        checkTranslationStatus();

    } catch (error) {
        console.error("⚠️ 번역 완료 대기 중 오류:", error);
        // 오류 발생 시에도 저장 버튼 클릭 시도
        clickSaveButton();
    }
}

// 수정사항 저장 버튼 클릭 함수
function clickSaveButton() {
    try {
        console.log("🔍 '수정사항 저장' 버튼 찾는 중...");

        // 수정사항 저장 버튼 찾기 (여러 방법으로 시도)
        let saveButton = null;

        // 방법 1: 클래스명과 텍스트로 찾기
        const buttons = Array.from(document.querySelectorAll("button.ant-btn.ant-btn-primary"))
            .filter(btn => {
                const textContent = btn.textContent || btn.innerText || '';
                return textContent.includes("수정사항 저장");
            });

        if (buttons.length > 0) {
            saveButton = buttons[0];
        }

        // 방법 2: save 아이콘이 있는 버튼 찾기
        if (!saveButton) {
            const iconButtons = Array.from(document.querySelectorAll("button"))
                .filter(btn => {
                    const saveIcon = btn.querySelector('[data-icon="save"]');
                    const textSpan = btn.querySelector('span:last-child');
                    return saveIcon && textSpan && textSpan.textContent.includes("수정사항 저장");
                });

            if (iconButtons.length > 0) {
                saveButton = iconButtons[0];
            }
        }

        if (saveButton) {
            console.log("✅ '수정사항 저장' 버튼 발견!");

            // 화면에 보이도록 스크롤
            saveButton.scrollIntoView({ behavior: 'smooth', block: 'center' });

            setTimeout(() => {
                saveButton.click();
                console.log("👉 '수정사항 저장' 버튼 클릭 완료");

                // 저장 버튼 클릭 후 0.5초 안정성 딜레이
                setTimeout(() => {
                    // 저장 완료 후 썸네일 탭 클릭
                    setTimeout(() => {
                        clickThumbnailTab();
                    }, 2000);
                }, 500);
            }, 500);

        } else {
            console.warn("⚠️ '수정사항 저장' 버튼을 찾을 수 없음");
        }

    } catch (error) {
        console.error("⚠️ '수정사항 저장' 버튼 클릭 실패:", error);
    }
}

// 썸네일 탭 클릭 함수
function clickThumbnailTab() {
    try {
        console.log("🔍 '썸네일' 탭 찾는 중...");

        // 썸네일 탭 찾기 (data-node-key="4" 또는 텍스트로 찾기)
        let thumbnailTab = null;

        // 방법 1: data-node-key="4"로 찾기
        const tabWithKey = document.querySelector('[data-node-key="4"] .ant-tabs-tab-btn');
        if (tabWithKey) {
            const spanText = tabWithKey.querySelector('span');
            if (spanText && spanText.textContent.trim() === "썸네일") {
                thumbnailTab = tabWithKey;
            }
        }

        // 방법 2: 텍스트로 찾기 (백업)
        if (!thumbnailTab) {
            const tabButtons = Array.from(document.querySelectorAll('.ant-tabs-tab-btn'))
                .filter(btn => {
                    const span = btn.querySelector('span');
                    return span && span.textContent.trim() === "썸네일";
                });

            if (tabButtons.length > 0) {
                thumbnailTab = tabButtons[0];
            }
        }

        if (thumbnailTab) {
            console.log("✅ '썸네일' 탭 발견!");

            // 화면에 보이도록 스크롤
            thumbnailTab.scrollIntoView({ behavior: 'smooth', block: 'center' });

            setTimeout(() => {
                thumbnailTab.click();
                console.log("👉 '썸네일' 탭 클릭 완료");

                // 썸네일 탭 클릭 후 첫 번째 썸네일 편집하기 버튼 클릭
                setTimeout(() => {
                    clickFirstThumbnailEditButton();
                }, 2000);
            }, 500);

        } else {
            console.log("⚠️ '썸네일' 탭을 찾을 수 없음");
            // 썸네일 탭을 찾을 수 없는 경우 바로 뒤로가기
            goBackToPreviousScreen();
        }

    } catch (error) {
        console.error("⚠️ '썸네일' 탭 클릭 실패:", error);
        // 오류 발생 시에도 뒤로가기
        goBackToPreviousScreen();
    }
}

// 이전 화면으로 돌아가기 함수
function goBackToPreviousScreen() {
    try {
        console.log("🔙 이전 화면으로 돌아가는 중...");

        // 브라우저 뒤로가기
        window.history.back();

        console.log("✅ 이전 화면으로 돌아가기 완료");

    } catch (error) {
        console.error("⚠️ 이전 화면으로 돌아가기 실패:", error);
    }
}

// 첫 번째 썸네일의 편집하기 버튼 클릭 함수
function clickFirstThumbnailEditButton() {
    try {
        console.log("🔍 첫 번째 썸네일 '편집하기' 버튼 찾는 중...");

        // 썸네일 그리드 컨테이너 찾기
        const thumbnailGrid = document.querySelector(".ant-row.ant-row-bottom");

        if (!thumbnailGrid) {
            console.log("⚠️ 썸네일 그리드를 찾을 수 없음");
            // 그리드를 찾을 수 없는 경우 상세페이지로 이동
            clickDetailPageTab();
            return;
        }

        // 첫 번째 썸네일 컨테이너 찾기 (Upload 버튼 제외)
        const thumbnailCols = Array.from(thumbnailGrid.querySelectorAll(".ant-col"))
            .filter(col => {
                // 실제 이미지가 있는 컬럼만 필터링 (sc-fedTIj 클래스가 있고 plus 아이콘이 없는 것)
                const thumbnailContainer = col.querySelector(".sc-fedTIj");
                const plusIcon = col.querySelector('[aria-label="plus"]');
                const img = col.querySelector("img.sc-APcvf");

                return thumbnailContainer && !plusIcon && img;
            });

        if (thumbnailCols.length === 0) {
            console.log("⚠️ 편집 가능한 썸네일을 찾을 수 없음");
            clickDetailPageTab();
            return;
        }

        // 첫 번째 썸네일의 편집하기 버튼 찾기
        const firstThumbnail = thumbnailCols[0];

        // 방법 1: sc-leQnM 클래스와 edit 아이콘으로 찾기
        let editButton = firstThumbnail.querySelector(".sc-leQnM.jxFFxk");

        // 방법 2: edit 아이콘이 있는 div 찾기 (백업)
        if (!editButton) {
            const editContainers = Array.from(firstThumbnail.querySelectorAll("div"))
                .filter(div => {
                    const editIcon = div.querySelector('[aria-label="edit"]');
                    const editText = div.querySelector('span');
                    return editIcon && editText && editText.textContent && editText.textContent.includes("편집하기");
                });

            if (editContainers.length > 0) {
                editButton = editContainers[0];
            }
        }

        // 방법 3: 직접 텍스트로 찾기 (최종 백업)
        if (!editButton) {
            const allDivs = Array.from(firstThumbnail.querySelectorAll("div"));
            for (const div of allDivs) {
                if (div.textContent && div.textContent.includes("편집하기")) {
                    editButton = div;
                    break;
                }
            }
        }

        if (editButton) {
            console.log("✅ 첫 번째 썸네일 '편집하기' 버튼 발견!");

            // 화면에 보이도록 스크롤
            editButton.scrollIntoView({ behavior: 'smooth', block: 'center' });

            setTimeout(() => {
                editButton.click();
                console.log("👉 첫 번째 썸네일 '편집하기' 버튼 클릭 완료");

                // 편집하기 버튼 클릭 후 전체 이미지 번역 버튼 클릭
                setTimeout(() => {
                    clickImageTranslateButtonInThumbnail();
                }, 2000);
            }, 500);

        } else {
            console.log("⚠️ 첫 번째 썸네일의 '편집하기' 버튼을 찾을 수 없음");
            clickDetailPageTab();
        }

    } catch (error) {
        console.error("⚠️ 첫 번째 썸네일 '편집하기' 버튼 클릭 실패:", error);
        clickDetailPageTab();
    }
}

// 썸네일 편집 화면에서 전체 이미지 번역 버튼 클릭 함수
function clickImageTranslateButtonInThumbnail() {
    try {
        console.log("🔍 썸네일 편집 화면에서 '전체 이미지 번역' 버튼 찾는 중...");

        // 개선된 버튼 탐지 및 클릭 로직 사용
        waitForButtonAndClick('p-translate-all-btn', (button) => {
            console.log("✅ 썸네일 편집 화면에서 '전체 이미지 번역' 버튼 발견!");

            // 화면에 보이도록 스크롤
            button.scrollIntoView({ behavior: 'smooth', block: 'center' });

            // 버튼 클릭
            button.click();
            console.log("👉 썸네일 편집 화면에서 '전체 이미지 번역' 버튼 클릭 완료");

            // 번역 완료 대기 (기본 로직 사용)
            waitForThumbnailTranslationComplete();
        });

    } catch (error) {
        console.error("⚠️ 썸네일 편집 화면에서 '전체 이미지 번역' 버튼 클릭 실패:", error);
        goBackToPreviousScreen();
    }
}

// 썸네일 번역 완료 대기 및 저장 버튼 클릭 함수
function waitForThumbnailTranslationComplete() {
    try {
        console.log("⏳ 썸네일 이미지 번역 완료 대기 중...");

        const checkTranslationStatus = () => {
            // P_TRANSLATE 객체와 running 상태 확인
            if (window.P_TRANSLATE && !window.P_TRANSLATE.running) {
                console.log("✅ 썸네일 이미지 번역 완료 감지!");

                // 번역 완료 후 저장 버튼 클릭 (이미지 저장 완료 대기 위해 딜레이 증가)
                setTimeout(() => {
                    clickSaveButtonInThumbnail();
                }, 2000);

                return;
            }

            // 스피너 확인 (추가적인 완료 신호)
            const spinnerElement = document.querySelector('#p-translate-all-btn .p-spin');
            if (spinnerElement && spinnerElement.style.display === 'none') {
                console.log("✅ 썸네일 편집에서 스피너 숨김 확인 - 번역 완료!");

                setTimeout(() => {
                    clickSaveButtonInThumbnail();
                }, 2000);

                return;
            }

            // 1초 후 재확인
            setTimeout(checkTranslationStatus, 1000);
        };

        // 번역 상태 확인 시작
        checkTranslationStatus();

    } catch (error) {
        console.error("⚠️ 썸네일 번역 완료 대기 중 오류:", error);
        // 오류 발생 시에도 저장 버튼 클릭 시도
        clickSaveButtonInThumbnail();
    }
}

// 썸네일 편집 화면에서 수정사항 저장 버튼 클릭 함수
function clickSaveButtonInThumbnail() {
    try {
        console.log("🔍 썸네일 편집 화면에서 '수정사항 저장' 버튼 찾는 중...");

        // 수정사항 저장 버튼 찾기 (여러 방법으로 시도)
        let saveButton = null;

        // 방법 1: 클래스명과 텍스트로 찾기
        const buttons = Array.from(document.querySelectorAll("button.ant-btn.ant-btn-primary"))
            .filter(btn => {
                const textContent = btn.textContent || btn.innerText || '';
                return textContent.includes("수정사항 저장");
            });

        if (buttons.length > 0) {
            saveButton = buttons[0];
        }

        // 방법 2: save 아이콘이 있는 버튼 찾기
        if (!saveButton) {
            const iconButtons = Array.from(document.querySelectorAll("button"))
                .filter(btn => {
                    const saveIcon = btn.querySelector('[data-icon="save"]');
                    const textSpan = btn.querySelector('span:last-child');
                    return saveIcon && textSpan && textSpan.textContent.includes("수정사항 저장");
                });

            if (iconButtons.length > 0) {
                saveButton = iconButtons[0];
            }
        }

        if (saveButton) {
            console.log("✅ 썸네일 편집 화면에서 '수정사항 저장' 버튼 발견!");

            // 화면에 보이도록 스크롤
            saveButton.scrollIntoView({ behavior: 'smooth', block: 'center' });

            setTimeout(() => {
                saveButton.click();
                console.log("👉 썸네일 편집 화면에서 '수정사항 저장' 버튼 클릭 완료");

                // 저장 버튼 클릭 후 0.5초 안정성 딜레이
                setTimeout(() => {
                    // 저장 완료 후 상세페이지 탭으로 이동
                    setTimeout(() => {
                        clickDetailPageTab();
                    }, 2000);
                }, 500);
            }, 500);

        } else {
            console.log("⚠️ 썸네일 편집 화면에서 '수정사항 저장' 버튼을 찾을 수 없음");
            // 저장 버튼을 찾을 수 없는 경우에도 상세페이지로 이동
            clickDetailPageTab();
        }

    } catch (error) {
        console.error("⚠️ 썸네일 편집 화면에서 '수정사항 저장' 버튼 클릭 실패:", error);
        clickDetailPageTab();
    }
}

// 상세페이지 탭 클릭 함수
function clickDetailPageTab() {
    try {
        console.log("🔍 '상세페이지' 탭 찾는 중...");

        // 상세페이지 탭 찾기 (data-node-key="5" 또는 텍스트로 찾기)
        let detailPageTab = null;

        // 방법 1: data-node-key="5"로 찾기
        const tabWithKey = document.querySelector('[data-node-key="5"] .ant-tabs-tab-btn');
        if (tabWithKey) {
            const spanText = tabWithKey.querySelector('span');
            if (spanText && spanText.textContent.trim() === "상세페이지") {
                detailPageTab = tabWithKey;
            }
        }

        // 방법 2: 텍스트로 찾기 (백업)
        if (!detailPageTab) {
            const tabButtons = Array.from(document.querySelectorAll('.ant-tabs-tab-btn'))
                .filter(btn => {
                    const span = btn.querySelector('span');
                    return span && span.textContent.trim() === "상세페이지";
                });

            if (tabButtons.length > 0) {
                detailPageTab = tabButtons[0];
            }
        }

        if (detailPageTab) {
            console.log("✅ '상세페이지' 탭 발견!");

            // 화면에 보이도록 스크롤
            detailPageTab.scrollIntoView({ behavior: 'smooth', block: 'center' });

            setTimeout(() => {
                detailPageTab.click();
                console.log("👉 '상세페이지' 탭 클릭 완료");

                // 상세페이지 탭 클릭 후 일괄 편집 버튼 클릭
                setTimeout(() => {
                    clickBulkEditButton();
                }, 2000);
            }, 500);

        } else {
            console.log("⚠️ '상세페이지' 탭을 찾을 수 없음");
            // 상세페이지 탭을 찾을 수 없는 경우 ESC로 메인 페이지로 복귀
            goBackToMainPage();
        }

    } catch (error) {
        console.error("⚠️ '상세페이지' 탭 클릭 실패:", error);
        // 오류 발생 시에도 메인 페이지로 복귀
        goBackToMainPage();
    }
}

// 일괄 편집 버튼 클릭 함수
function clickBulkEditButton() {
    try {
        console.log("🔍 '일괄 편집' 버튼 찾는 중...");

        // 일괄 편집 버튼 찾기 (여러 방법으로 시도)
        let bulkEditButton = null;

        // 방법 1: 정확한 클래스와 form 아이콘을 가진 버튼 찾기
        const formIconButtons = Array.from(document.querySelectorAll("button.ant-btn.sc-knefzF.jnxjqd"))
            .filter(btn => {
                const formIcon = btn.querySelector('[data-icon="form"]');
                const textSpan = btn.querySelector('span:last-child');
                return formIcon && textSpan && textSpan.textContent && textSpan.textContent.trim() === "일괄 편집";
            });

        if (formIconButtons.length > 0) {
            bulkEditButton = formIconButtons[0];
        }

        // 방법 2: form 아이콘이 있는 버튼 찾기 (백업)
        if (!bulkEditButton) {
            const buttons = Array.from(document.querySelectorAll("button"))
                .filter(btn => {
                    const formIcon = btn.querySelector('[aria-label="form"]');
                    const textContent = btn.textContent || btn.innerText || '';
                    return formIcon && textContent.includes("일괄 편집");
                });

            if (buttons.length > 0) {
                bulkEditButton = buttons[0];
            }
        }

        // 방법 3: 일반 텍스트로 찾기 (최종 백업)
        if (!bulkEditButton) {
            const buttons = Array.from(document.querySelectorAll("button"))
                .filter(btn => {
                    const textContent = btn.textContent || btn.innerText || '';
                    return textContent.includes("일괄 편집");
                });

            if (buttons.length > 0) {
                bulkEditButton = buttons[0];
            }
        }

        if (bulkEditButton) {
            console.log("✅ '일괄 편집' 버튼 발견!");

            // 화면에 보이도록 스크롤
            bulkEditButton.scrollIntoView({ behavior: 'smooth', block: 'center' });

            setTimeout(() => {
                bulkEditButton.click();
                console.log("👉 '일괄 편집' 버튼 클릭 완료");

                // 일괄 편집 버튼 클릭 후 첫 번째 편집하기 버튼 클릭
                setTimeout(() => {
                    clickFirstDetailEditButton();
                }, 2000);
            }, 500);

        } else {
            console.log("⚠️ '일괄 편집' 버튼을 찾을 수 없음");
            // 버튼을 찾을 수 없는 경우 메인 페이지로 복귀
            goBackToMainPage();
        }

    } catch (error) {
        console.error("⚠️ '일괄 편집' 버튼 클릭 실패:", error);
        goBackToMainPage();
    }
}

// 클릭 가능한 부모 요소 찾기 함수 (새로 추가)
function findClickableParent(element) {
    let current = element;
    let attempts = 0;
    const maxAttempts = 8; // 최대 8단계까지 부모 탐색
    
    while (current && attempts < maxAttempts) {
        // 클릭 이벤트나 커서 스타일이 있는 요소 찾기
        const style = window.getComputedStyle(current);
        const hasClickCursor = style.cursor === 'pointer';
        const hasOnClick = current.onclick || current.getAttribute('onclick');
        const hasClickListener = current._reactListeners || current._reactInternalFiber;
        
        // React 컴포넌트 확인 (React Fiber 존재 여부)
        const hasReactProps = Object.keys(current).some(key => 
            key.startsWith('__reactFiber') || key.startsWith('__reactProps')
        );
        
        // 클릭 가능한 요소의 조건
        const isClickable = (
            hasClickCursor || 
            hasOnClick || 
            hasClickListener ||
            hasReactProps ||
            // 특정 클래스 패턴 (카드나 버튼 컨테이너)
            current.classList.contains('sc-kypfzD') ||
            current.classList.contains('jtxKEG') ||
            current.classList.contains('ant-col') ||
            // 인라인 스타일로 커서 포인터 설정
            current.style.cursor === 'pointer'
        );
        
        // 클릭 가능하고 적절한 크기를 가진 요소
        if (isClickable && current.offsetWidth > 0 && current.offsetHeight > 0) {
            console.log(`✅ 클릭 가능한 부모 발견: ${current.tagName}.${current.className}`);
            return current;
        }
        
        current = current.parentElement;
        attempts++;
    }
    
    // 클릭 가능한 부모를 찾지 못한 경우 원래 요소 반환
    console.log("⚠️ 클릭 가능한 부모를 찾지 못함 - 원본 요소 사용");
    return element;
}

// 상세페이지에서 첫 번째 편집하기 버튼 클릭 함수 (수정된 버전)
function clickFirstDetailEditButton() {
    try {
        console.log("🔍 상세페이지에서 첫 번째 '편집하기' 버튼 찾는 중...");

        // 페이지 로딩 대기 후 검색
        setTimeout(() => {
            let firstEditButton = null;

            // 방법 1: HTML 구조에 기반한 정확한 셀렉터 - 수정된 버전
            const editContainers = document.querySelectorAll(".sc-dLmyTH.iBFkHP");
            if (editContainers.length > 0) {
                console.log(`✅ 발견된 편집하기 컨테이너: ${editContainers.length}개`);
                
                // 실제 "편집하기" 텍스트가 있는 첫 번째 컨테이너 찾기
                for (const container of editContainers) {
                    const editSpan = container.querySelector('span.sc-hMBXfw.dzWYcO.FootnoteDescription');
                    if (editSpan && editSpan.textContent && editSpan.textContent.trim() === "편집하기") {
                        // 클릭 가능한 영역 찾기 - 개선된 로직
                        firstEditButton = findClickableParent(container);
                        console.log("✅ 방법1: 첫 번째 편집하기 컨테이너 발견");
                        break;
                    }
                }
            }

            // 방법 2: 이미지 카드와 편집 버튼 조합 (백업)
            if (!firstEditButton) {
                const imageCards = document.querySelectorAll(".sc-kypfzD.jtxKEG");
                for (const card of imageCards) {
                    const editContainer = card.querySelector('.sc-dLmyTH.iBFkHP');
                    const editSpan = card.querySelector('span.sc-hMBXfw.dzWYcO.FootnoteDescription');
                    
                    if (editContainer && editSpan && editSpan.textContent.includes("편집하기")) {
                        firstEditButton = findClickableParent(editContainer);
                        console.log("✅ 방법2: 이미지 카드에서 편집하기 발견");
                        break;
                    }
                }
            }

            // 방법 3: 직접 클릭 가능한 부모 찾기 (최종 백업)
            if (!firstEditButton) {
                const allEditSpans = Array.from(document.querySelectorAll('span'))
                    .filter(span => span.textContent && span.textContent.trim() === "편집하기");
                
                if (allEditSpans.length > 0) {
                    firstEditButton = findClickableParent(allEditSpans[0]);
                    console.log("✅ 방법3: 직접 텍스트 검색으로 편집하기 발견");
                }
            }

            if (firstEditButton) {
                console.log("✅ 상세페이지에서 첫 번째 '편집하기' 버튼 발견!");

                // 화면에 보이도록 스크롤
                firstEditButton.scrollIntoView({ behavior: 'smooth', block: 'center' });

                setTimeout(() => {
                    // 강화된 클릭 메커니즘 적용
                    clickButtonWithRetry(firstEditButton, "상세페이지 편집하기", () => {
                        console.log("👉 상세페이지에서 첫 번째 '편집하기' 버튼 클릭 완료");

                        // 편집하기 버튼 클릭 후 전체 이미지 번역 버튼 클릭
                        setTimeout(() => {
                            clickImageTranslateButtonInDetailPage();
                        }, 3000);
                    });
                }, 500);

            } else {
                console.log("⚠️ 상세페이지에서 '편집하기' 버튼을 찾을 수 없음 → 메인 페이지로 복귀");
                goBackToMainPage();
            }

        }, 1500); // 페이지 로딩 대기 시간

    } catch (error) {
        console.error("⚠️ 상세페이지에서 '편집하기' 버튼 클릭 실패:", error);
        goBackToMainPage();
    }
}

// 상세페이지 편집에서 전체 이미지 번역 버튼 클릭 함수
function clickImageTranslateButtonInDetailPage() {
    try {
        console.log("🔍 상세페이지 편집에서 '전체 이미지 번역' 버튼 찾는 중...");

        // 우선 개선된 버튼 탐지 로직으로 시도
        waitForButtonAndClick('p-translate-all-btn', (button) => {
            console.log("✅ 상세페이지에서 '전체 이미지 번역' 버튼 발견!");

            // 화면에 보이도록 스크롤
            button.scrollIntoView({ behavior: 'smooth', block: 'center' });

            // 버튼 클릭
            button.click();
            console.log("👉 상세페이지에서 '전체 이미지 번역' 버튼 클릭 완료");

            // 번역 완료 대기 (기본 로직 사용)
            waitForDetailPageTranslationComplete();
        });

        // 기본 로직으로 찾지 못하는 경우를 위한 백업 (3초 후)
        setTimeout(() => {
            const existingBtn = document.getElementById('p-translate-all-btn');
            if (!existingBtn) {
                console.log("🔄 기본 로직으로 찾지 못함 → 고급 탐지 모드 실행");
                findTranslateButtonWithRetry(0);
            }
        }, 3000);

    } catch (error) {
        console.error("⚠️ 상세페이지 편집에서 '전체 이미지 번역' 버튼 클릭 실패:", error);
        goBackToMainPage();
    }
}

// 번역 버튼 탐지 재시도 함수 (개선된 버전)
function findTranslateButtonWithRetry(attemptCount, maxAttempts = 5) {
    const attempt = attemptCount + 1;
    console.log(`🔍 번역 버튼 탐지 시도 ${attempt}/${maxAttempts}`);

    // 다중 셀렉터로 번역 버튼 찾기
    let imageTranslateBtn = null;

    // 방법 1: ID로 찾기 (기본)
    imageTranslateBtn = document.getElementById('p-translate-all-btn');

    // 방법 2: 클래스와 텍스트로 찾기
    if (!imageTranslateBtn) {
        const buttons = Array.from(document.querySelectorAll('button, div[role="button"], span[role="button"]'))
            .filter(btn => {
                const text = btn.textContent || btn.innerText || '';
                return text.includes('전체 이미지 번역') || text.includes('원클릭 이미지 번역');
            });
        if (buttons.length > 0) {
            imageTranslateBtn = buttons[0];
            console.log("✅ 방법2: 텍스트로 번역 버튼 발견");
        }
    }

    // 방법 3: 특정 클래스 조합으로 찾기
    if (!imageTranslateBtn) {
        const selectors = [
            '[id*="translate"]',
            '[class*="translate"]',
            '[data-*="translate"]',
            'button[title*="번역"]',
            'div[title*="번역"]'
        ];

        for (const selector of selectors) {
            const elements = document.querySelectorAll(selector);
            for (const el of elements) {
                const text = el.textContent || el.innerText || el.title || '';
                if (text.includes('번역') && text.includes('이미지')) {
                    imageTranslateBtn = el;
                    console.log(`✅ 방법3: 셀렉터 ${selector}로 번역 버튼 발견`);
                    break;
                }
            }
            if (imageTranslateBtn) break;
        }
    }

    if (imageTranslateBtn) {
        console.log("✅ 상세페이지 편집에서 '전체 이미지 번역' 버튼 발견!");

        // 화면에 보이도록 스크롤
        imageTranslateBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });

        setTimeout(() => {
            // 버튼 클릭
            imageTranslateBtn.click();
            console.log("👉 상세페이지 편집에서 '전체 이미지 번역' 버튼 클릭 완료");

            // 번역 완료 대기 (기본 로직 사용)
            waitForDetailPageTranslationComplete();
        }, 800);

    } else if (attemptCount < maxAttempts - 1) {
        console.log(`⚠️ 번역 버튼을 찾지 못함 - ${2 + attemptCount}초 후 재시도`);
        // 재시도 간격을 점진적으로 증가
        const retryDelay = 2000 + (attemptCount * 1000);
        setTimeout(() => {
            findTranslateButtonWithRetry(attemptCount + 1, maxAttempts);
        }, retryDelay);
    } else {
        console.log("❌ 최대 재시도 횟수 초과 - 번역 버튼을 찾을 수 없음");
        goBackToMainPage();
    }
}

// 상세페이지 번역 완료 대기 함수
function waitForDetailPageTranslationComplete() {
    try {
        console.log("⏳ 상세페이지 이미지 번역 완료 대기 중...");

        const checkTranslationStatus = () => {
            // P_TRANSLATE 객체와 running 상태 확인
            if (window.P_TRANSLATE && !window.P_TRANSLATE.running) {
                console.log("✅ 상세페이지 이미지 번역 완료 감지!");

                // 번역 완료 후 저장 버튼 클릭 (이미지 저장 완료 대기 위해 딜레이 증가)
                setTimeout(() => {
                    clickSaveButtonInDetailPage();
                }, 2000);

                return;
            }

            // 스피너 확인 (추가적인 완료 신호)
            const spinnerElement = document.querySelector('#p-translate-all-btn .p-spin');
            if (spinnerElement && spinnerElement.style.display === 'none') {
                console.log("✅ 상세페이지 편집에서 스피너 숨김 확인 - 번역 완료!");

                setTimeout(() => {
                    clickSaveButtonInDetailPage();
                }, 2000);

                return;
            }

            // 1초 후 재확인
            setTimeout(checkTranslationStatus, 1000);
        };

        // 번역 상태 확인 시작
        checkTranslationStatus();

    } catch (error) {
        console.error("⚠️ 상세페이지 번역 완료 대기 중 오류:", error);
        // 오류 발생 시에도 저장 버튼 클릭 시도
        clickSaveButtonInDetailPage();
    }
}

// 상세페이지 편집에서 수정사항 저장 버튼 클릭 함수
function clickSaveButtonInDetailPage() {
    try {
        console.log("🔍 상세페이지 편집에서 '수정사항 저장' 버튼 찾는 중...");

        // 수정사항 저장 버튼 찾기 (여러 방법으로 시도)
        let saveButton = null;

        // 방법 1: 클래스명과 텍스트로 찾기
        const buttons = Array.from(document.querySelectorAll("button.ant-btn.ant-btn-primary"))
            .filter(btn => {
                const textContent = btn.textContent || btn.innerText || '';
                return textContent.includes("수정사항 저장");
            });

        if (buttons.length > 0) {
            saveButton = buttons[0];
        }

        // 방법 2: save 아이콘이 있는 버튼 찾기
        if (!saveButton) {
            const iconButtons = Array.from(document.querySelectorAll("button"))
                .filter(btn => {
                    const saveIcon = btn.querySelector('[data-icon="save"]');
                    const textSpan = btn.querySelector('span:last-child');
                    return saveIcon && textSpan && textSpan.textContent.includes("수정사항 저장");
                });

            if (iconButtons.length > 0) {
                saveButton = iconButtons[0];
            }
        }

        if (saveButton) {
            console.log("✅ 상세페이지 편집에서 '수정사항 저장' 버튼 발견!");

            // 화면에 보이도록 스크롤
            saveButton.scrollIntoView({ behavior: 'smooth', block: 'center' });

            setTimeout(() => {
                saveButton.click();
                console.log("👉 상세페이지 편집에서 '수정사항 저장' 버튼 클릭 완료");

                // 저장 버튼 클릭 후 0.5초 안정성 딜레이
                setTimeout(() => {
                    // 저장 완료 후 메인 페이지로 돌아가기 (ESC 키 시퀀스)
                    setTimeout(() => {
                        goBackToMainPage();
                    }, 2000);
                }, 500);
            }, 500);

        } else {
            console.log("⚠️ 상세페이지 편집에서 '수정사항 저장' 버튼을 찾을 수 없음");
            goBackToMainPage();
        }

    } catch (error) {
        console.error("⚠️ 상세페이지 편집에서 '수정사항 저장' 버튼 클릭 실패:", error);
        goBackToMainPage();
    }
}

// 강화된 버튼 클릭 함수 (재시도 로직 포함)
function clickButtonWithRetry(button, label, callback, maxRetries = 3) {
    let retryCount = 0;

    function attemptClick() {
        try {
            console.log(`🔄 ${label} 버튼 클릭 시도 ${retryCount + 1}/${maxRetries}`);

            // 초기 URL 저장 (첫 번째 시도에서만)
            if (retryCount === 0 && !window.initialUrl) {
                window.initialUrl = window.location.href;
            }

            // DOM 상태 확인
            if (!button || !button.parentNode) {
                console.log(`⚠️ ${label} 버튼이 DOM에서 제거됨`);
                if (retryCount < maxRetries - 1) {
                    retryCount++;
                    setTimeout(attemptClick, 1000);
                    return;
                } else {
                    console.log(`❌ ${label} 버튼 클릭 실패 - 최대 재시도 횟수 초과`);
                    return;
                }
            }

            // 클릭 전 초기 상태 확인
            const initialState = {
                hasTranslateButton: !!document.getElementById('p-translate-all-btn'),
                activeElements: document.querySelectorAll('[class*="active"], [class*="selected"]').length
            };

            // 다중 클릭 방식 적용 (보강된 버전)

            // 요소가 화면에 보이도록 스크롤
            button.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });

            // 짧은 지연 후 클릭 (스크롤 완료 대기)
            setTimeout(() => {
                // 1. 기본 클릭
                button.click();

                // 2. 정확한 좌표 계산으로 마우스 이벤트 클릭
                const rect = button.getBoundingClientRect();
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;

                // mousedown -> mouseup -> click 시퀀스
                const mouseDownEvent = new MouseEvent('mousedown', {
                    bubbles: true,
                    cancelable: true,
                    view: window,
                    clientX: centerX,
                    clientY: centerY,
                    button: 0
                });

                const mouseUpEvent = new MouseEvent('mouseup', {
                    bubbles: true,
                    cancelable: true,
                    view: window,
                    clientX: centerX,
                    clientY: centerY,
                    button: 0
                });

                const clickEvent = new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                    view: window,
                    clientX: centerX,
                    clientY: centerY,
                    button: 0
                });

                button.dispatchEvent(mouseDownEvent);
                setTimeout(() => {
                    button.dispatchEvent(mouseUpEvent);
                    setTimeout(() => {
                        button.dispatchEvent(clickEvent);
                    }, 10);
                }, 10);

                // 3. 포커스 후 엔터 키 (50ms 지연)
                setTimeout(() => {
                    if (button.focus) {
                        button.focus();
                        button.dispatchEvent(new KeyboardEvent('keydown', {
                            key: 'Enter',
                            code: 'Enter',
                            keyCode: 13,
                            bubbles: true
                        }));
                    }
                }, 50);

                console.log(`✅ ${label} 버튼 다중 클릭 실행 완료`);

                // 클릭 후 DOM 변화 검증 (강화된 버전) - 클릭 완료 후 적절한 지연
                setTimeout(() => {
                        const newState = {
                            hasTranslateButton: !!document.getElementById('p-translate-all-btn'),
                            activeElements: document.querySelectorAll('[class*="active"], [class*="selected"]').length,
                            hasModal: !!document.querySelector('.ant-modal, .ant-drawer, .modal'),
                            hasEditor: !!document.querySelector('[class*="editor"], [class*="edit"]'),
                            urlChanged: window.location.href !== (window.initialUrl || window.location.href),
                            hasLoadingState: !!document.querySelector('[class*="loading"], [class*="spin"]')
                        };

                        // 여러 가지 상태 변화 확인
                        const stateChanged = (
                            // 기존 검증
                            initialState.hasTranslateButton !== newState.hasTranslateButton ||
                            initialState.activeElements !== newState.activeElements ||
                            // 새로운 검증
                            newState.hasModal ||  // 모달이나 드로어가 열렸는지
                            newState.hasEditor || // 에디터가 활성화되었는지
                            newState.urlChanged || // URL이 변경되었는지
                            newState.hasLoadingState // 로딩 상태가 있는지
                        );

                        console.log(`🔍 ${label} 클릭 후 상태:`, {
                            '번역버튼': newState.hasTranslateButton,
                            '활성요소': newState.activeElements,
                            '모달열림': newState.hasModal,
                            '에디터활성': newState.hasEditor,
                            'URL변경': newState.urlChanged,
                            '로딩상태': newState.hasLoadingState,
                            '상태변화': stateChanged
                        });

                        if (stateChanged) {
                            console.log(`✅ ${label} 버튼 클릭 효과 확인됨`);
                            if (callback) callback();
                        } else if (retryCount < maxRetries - 1) {
                            console.log(`⚠️ ${label} 버튼 클릭 효과 없음 - 재시도`);
                            retryCount++;
                            // 점진적 재시도 간격 (1초, 2초, 3초)
                            const retryDelay = 1000 + (retryCount * 1000);
                            console.log(`🔄 ${retryDelay/1000}초 후 재시도 (${retryCount + 1}/${maxRetries})`);
                            setTimeout(attemptClick, retryDelay);
                        } else {
                            console.log(`❌ ${label} 버튼 클릭 실패 - 최대 재시도 횟수 초과`);
                            if (callback) callback(); // 실패해도 다음 단계 진행
                        }
                    }, 1500);

                }, 100); // 스크롤 완료 대기

        } catch (error) {
            console.error(`⚠️ ${label} 버튼 클릭 중 오류:`, error);
            if (retryCount < maxRetries - 1) {
                retryCount++;
                setTimeout(attemptClick, 1000);
            } else {
                console.log(`❌ ${label} 버튼 클릭 실패 - 최대 재시도 횟수 초과`);
                if (callback) callback(); // 실패해도 다음 단계 진행
            }
        }
    }

    attemptClick();
}

/* =====================[ 여기부터 ESC 시퀀스 개선 - 인라인 추가 ]===================== */
/**
 * 한 문서 대상으로 ESC keydown + keyup 전송
 */
function sendEscToDoc(doc) {
  try {
    const win = doc.defaultView || window;
    const targets = new Set([win, doc, doc.body, doc.activeElement].filter(Boolean));
    const mk = (type) => new KeyboardEvent(type, {
      key: 'Escape',
      code: 'Escape',
      keyCode: 27,
      which: 27,
      bubbles: true,
      cancelable: true
    });
    for (const t of targets) {
      try { t.dispatchEvent(mk('keydown')); } catch {}
      try { t.dispatchEvent(mk('keyup')); } catch {}
    }
  } catch {}
}

/**
 * 모든 문서(메인+iframe)에 ESC 브로드캐스트 1회
 */
function fireEscOnceAllDocs() {
  const docs = (typeof allDocs === 'function') ? allDocs() : [document];
  for (const d of docs) sendEscToDoc(d);
}

/**
 * 메인 페이지로 돌아가기: 저장 후 요구사항대로
 * (0.5초 대기) → ESC → (0.5초 대기) → ESC → (0.5초 대기) → 다음 체크 상품
 * 다른 로직/함수 호출부는 변경하지 않음
 */
function goBackToMainPage() {
  try {
    console.log("🔙 ESC 시퀀스 시작: 0.5s 대기 → ESC → 0.5s → ESC → 0.5s → 다음 아이템");

    // 0.5초 후 1차 ESC
    setTimeout(() => {
      fireEscOnceAllDocs();
      console.log("⎋ ESC #1 전송");

      // 추가 0.5초 후 2차 ESC
      setTimeout(() => {
        fireEscOnceAllDocs();
        console.log("⎋ ESC #2 전송");

        // 추가 0.5초 후 다음 체크 상품 처리
        setTimeout(() => {
          try {
            processNextCheckedItem();
          } catch (e) {
            console.error("⚠️ 다음 체크 상품 이동 중 오류:", e);
          }
        }, 500);

      }, 500);

    }, 500);

  } catch (error) {
    console.error("⚠️ goBackToMainPage 실행 오류:", error);
    // 실패해도 다음으로 진행은 시도
    setTimeout(() => {
      try { processNextCheckedItem(); } catch {}
    }, 1600);
  }
}
/* =====================[ ESC 시퀀스 개선 끝 ]===================== */

// 메인 페이지로 돌아가기 함수 (ESC 키 이용)  <<-- 기존 구현은 위에서 교체되었습니다.

// 다음 체크된 상품 처리 함수
function processNextCheckedItem() {
    try {
        console.log("🔄 다음 체크된 상품 처리 시작...");

        // 전체리스트 번역 버튼 다시 표시 확인
        ensureTranslateAllButtonVisible();

        // 이미 처리된 상품을 제외하고 다음 체크된 상품 찾기
        const rows = document.querySelectorAll("li.ant-list-item");
        let foundNext = false;

        rows.forEach((li, index) => {
            const idx = index + 1;
            try {
                const checkbox = li.querySelector("input.ant-checkbox-input");
                const isChecked = checkbox && (checkbox.checked || checkbox.getAttribute("checked") !== null);

                // 이미 처리된 상품인지 확인 (data 속성 사용)
                const isProcessed = li.getAttribute("data-processed") === "true";

                if (isChecked && !isProcessed && !foundNext) {
                    console.log(`Row ${idx}: ✅ 다음 처리 대상 상품 발견`);

                    // 현재 상품을 처리됨으로 표시
                    li.setAttribute("data-processed", "true");

                    // 세부사항 수정 및 업로드 버튼 찾기
                    const detailBtn = Array.from(li.querySelectorAll("button"))
                        .find(btn => {
                            const span = btn.querySelector("span");
                            return span && span.textContent.includes("세부사항 수정 및 업로드");
                        });

                    if (detailBtn) {
                        // 스크롤하여 버튼이 보이도록 조정
                        detailBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });

                        // 잠시 후 클릭
                        setTimeout(() => {
                            detailBtn.click();
                            console.log(`👉 Row ${idx}: '세부사항 수정 및 업로드' 버튼 클릭 완료`);

                            // 옵션 탭 클릭부터 시작
                            setTimeout(() => {
                                clickOptionTab();
                            }, 1000);
                        }, 500);

                        foundNext = true;
                        return;
                    }
                }

            } catch (e) {
                console.log(`Row ${idx}: ⚠️ 다음 상품 처리 중 오류 발생 → ${e}`);
            }
        });

        if (!foundNext) {
            console.log("🎉 모든 체크된 상품의 번역 처리가 완료되었습니다!");

            // 모든 처리 완료 시 data-processed 속성 정리
            rows.forEach(li => {
                li.removeAttribute("data-processed");
            });
        }

    } catch (error) {
        console.error("⚠️ 다음 체크된 상품 처리 중 오류:", error);
    }
}

// 전체리스트 번역 버튼이 항상 보이도록 확인하는 함수
function ensureTranslateAllButtonVisible() {
    try {
        if (!document.querySelector("#translateAllBtn")) {
            console.log("🔄 전체리스트 번역 버튼 재생성 시도...");

            const ellipsisIcon = document.querySelector("span[aria-label='ellipsis']");
            if (ellipsisIcon) {
                const ellipsisBtn = ellipsisIcon.closest("button");

                if (ellipsisBtn) {
                    const newBtn = document.createElement("button");
                    newBtn.id = "translateAllBtn";
                    newBtn.type = "button";

                    // ✅ 클래스 직접 지정
                    newBtn.className = "ant-btn css-1li46mu ant-btn-default";

                    // 버튼 스타일
                    newBtn.style.marginLeft = "8px";
                    newBtn.style.backgroundColor = "#1890ff";
                    newBtn.style.borderColor = "#1890ff";
                    newBtn.style.color = "white";

                    newBtn.innerHTML = `
                        <span class="ant-btn-icon">
                            <span role="img" aria-label="thunderbolt" class="anticon anticon-thunderbolt">
                                <svg viewBox="64 64 896 896" width="1em" height="1em" fill="currentColor" aria-hidden="true">
                                    <path d="M848 359.3H627.7L825.8 109c4.1-5.3.4-13-6.3-13H436c-2.8 0-5.5 1.5-6.9 4L170 547.5c-3.1 5.3.7 12 6.9 12h174.4l-89.4 357.6c-1.9 7.8 7.5 13.3 13.3 7.7L853.5 373c5.2-4.9 1.7-13.7-5.5-13.7zM378.2 732.5l60.3-241H281.1l189.6-327.4h224.6L487 427.4h211L378.2 732.5z"/>
                                </svg>
                            </span>
                        </span>
                        <span>전체리스트 번역</span>
                    `;

                    newBtn.addEventListener("click", () => {
                        document.body.setAttribute("translate-all", "true");
                        console.log("✅ 전체리스트 번역 버튼 클릭됨!");
                        processCheckedItems();
                    });

                    ellipsisBtn.parentNode.insertBefore(newBtn, ellipsisBtn.nextSibling);
                    console.log("🎉 전체리스트 번역 버튼 재생성 완료 (ellipsis 옆)");
                }
            }
        }
    } catch (error) {
        console.error("⚠️ 전체리스트 번역 버튼 재생성 실패:", error);
    }
}
