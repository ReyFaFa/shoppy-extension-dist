// Chrome Extension 자동 업데이트 시스템
// 이제 Chrome 자체 업데이트 메커니즘을 사용합니다.
class VersionChecker {
  constructor() {
    this.UPDATE_URL = 'https://reyfafa.github.io/ShoppyDelight/update.xml';
    this.CHECK_INTERVAL = 24 * 60 * 60 * 1000; // 24시간
  }

  // 현재 버전 가져오기
  async getCurrentVersion() {
    try {
      return chrome.runtime.getManifest().version;
    } catch (error) {
      console.error('[버전체크] 현재 버전 가져오기 실패:', error);
      return '알 수 없음';
    }
  }

  // Chrome 자동 업데이트 상태 확인
  async getAutoUpdateStatus() {
    const currentVersion = await this.getCurrentVersion();
    const updateUrl = chrome.runtime.getManifest().update_url;

    return {
      currentVersion,
      updateUrl,
      autoUpdateEnabled: !!updateUrl,
      lastCheck: new Date().toISOString(),
      mechanism: 'Chrome Native Auto-Update'
    };
  }

  // 수동 업데이트 체크 (사용자 요청 시에만)
  async checkForUpdatesManually() {
    try {
      console.log('[수동 업데이트 체크] 시작...');

      const status = await this.getAutoUpdateStatus();

      if (!status.autoUpdateEnabled) {
        return {
          success: false,
          message: '자동 업데이트가 설정되지 않았습니다.',
          status
        };
      }

      // Chrome의 자동 업데이트를 신뢰하고 안내만 제공
      return {
        success: true,
        message: `현재 버전: ${status.currentVersion}\n\nChrome이 자동으로 업데이트를 확인합니다.\n새 버전이 있으면 24시간 내에 자동으로 업데이트됩니다.`,
        status,
        recommendation: 'Chrome 자동 업데이트를 신뢰하세요. 수동 개입이 필요하지 않습니다.'
      };

    } catch (error) {
      console.error('[수동 업데이트 체크] 실패:', error);
      return {
        success: false,
        message: '업데이트 확인 중 오류가 발생했습니다.',
        error: error.message
      };
    }
  }

  // 업데이트 정보 표시 (간소화)
  async showUpdateInfo() {
    try {
      const status = await this.getAutoUpdateStatus();

      const message = `🛍️ Shoppy Extension 업데이트 정보

📦 현재 버전: ${status.currentVersion}
🔄 자동 업데이트: ${status.autoUpdateEnabled ? '활성화됨' : '비활성화됨'}
🌐 업데이트 URL: ${status.updateUrl || '설정되지 않음'}

✨ Chrome 자동 업데이트 시스템
• Chrome이 주기적으로 업데이트를 확인합니다
• 새 버전이 있으면 자동으로 다운로드하고 설치합니다
• 사용자의 별도 작업은 필요하지 않습니다

💡 수동 확인이 필요한 경우에만 이 기능을 사용하세요.`;

      // 알림 표시
      if (chrome.notifications) {
        chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icon48.png',
          title: 'Extension 업데이트 정보',
          message: '자동 업데이트가 활성화되어 있습니다.'
        });
      }

      return message;

    } catch (error) {
      console.error('[업데이트 정보 표시] 실패:', error);
      return '업데이트 정보를 가져올 수 없습니다.';
    }
  }

  // 레거시 호환성을 위한 메서드들 (간소화)
  async initializeChecker() {
    console.log('[버전체크] Chrome 자동 업데이트 시스템 초기화 완료');
    const status = await this.getAutoUpdateStatus();
    console.log('[버전체크] 상태:', status);
  }

  async checkForUpdates() {
    return this.checkForUpdatesManually();
  }

  // 기존 복잡한 업데이트 로직 제거
  // Chrome 자체 메커니즘을 사용하므로 더 이상 필요하지 않음
}

// 전역 인스턴스 생성 (기존 호환성 유지)
if (typeof window !== 'undefined') {
  window.versionChecker = new VersionChecker();

  // 초기화
  window.versionChecker.initializeChecker();
}

// 모듈 export (Node.js 환경용)
if (typeof module !== 'undefined' && module.exports) {
  module.exports = VersionChecker;
}