let popupWindowId = null;

// 메시지 리스너 추가 (bulk-translator.js에서 오는 로그 메시지 처리 + GPT 버튼 처리 + 강제 업데이트)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'log') {
    console.log(`[Bulk Translator] ${message.message}`);
  } else if (message.action === 'executePopupTranslation') {
    // GPT 버튼에서 팝업의 runButton과 동일한 번역 실행
    handlePopupTranslation(sender.tab.id, sendResponse);
    return true; // 비동기 응답을 위해 true 반환
  } else if (message.action === 'forceUpdateFiles') {
    // 강제 파일 업데이트 요청 처리
    handleForceUpdate(message.files, sendResponse);
    return true; // 비동기 응답을 위해 true 반환
  } else if (message.action === 'forceRestart') {
    // 강제 재시작 요청 처리
    handleForceRestart(sendResponse);
    return true; // 비동기 응답을 위해 true 반환
  } else if (message.action === 'executeUpdatedScript') {
    // 동적 스크립트 실행 요청 처리 (CSP 제약으로 인해 단순화)
    handleExecuteUpdatedScript(message.fileName, message.content, sendResponse);
    return true; // 비동기 응답을 위해 true 반환
  }
});

// GPT 버튼에서 팝업의 runButton과 동일한 번역 실행 처리
async function handlePopupTranslation(tabId, sendResponse) {
  try {
    console.log('[Background] GPT 버튼에서 팝업 방식 번역 실행');

    // 기본 설정 로드 (popup.js와 동일)
    const { apiKey, gptModel, shortcutKey } = await new Promise(resolve =>
      chrome.storage.sync.get(['apiKey', 'gptModel', 'shortcutKey'], resolve)
    );
    
    // 지침 데이터 청크 방식으로 로드 (옵션명 번역은 옵션명 지침만 사용)
    const instruction = await loadInstructionFromChunks('instruction');
    
    console.log(`[Background] 로드된 설정 - API 키: ${apiKey ? '설정됨' : '없음'}, 모델: ${gptModel || '없음'}, 옵션명 지침: ${instruction ? '있음' : '없음'}`);
    
    if (!apiKey) throw new Error('API 키가 설정되지 않았습니다.');
    if (!instruction) throw new Error('옵션명 지침이 설정되지 않았습니다.');

    console.log(`[Background] 사용된 옵션명 지침: ${instruction.substring(0, 100)}...`);

    // DOM 상태 최신화 및 텍스트 추출 (popup.js와 동일한 로직)
    const { texts, textSources } = await new Promise((resolve, reject) => {
      chrome.scripting.executeScript(
        {
          target: { tabId: tabId, allFrames: false },
          function: () => {
            const texts = [];
            const textSources = {};
            
            // 체크박스 상태 최신 확인
            const checkedItems = Array.from(document.querySelectorAll('li.ant-list-item'));
            checkedItems.forEach((item, index) => {
              const checkbox = item.querySelector('input[type="checkbox"][checked]');
              if (checkbox) {
                const span = item.querySelector('span.CharacterSecondary45');
                const text = span ? span.textContent.trim() : null;
                if (text && (text.match(/[\u4e00-\u9fff]/) || text.match(/[a-zA-Z]/))) {
                  texts.push(text);
                  textSources[text] = 'checkbox';
                }
              }
            });

            return { texts, textSources };
          },
        },
        (results) => {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          resolve(results[0]?.result || { texts: [], textSources: {} });
        }
      );
    });

    console.log(`[Background] 최종 추출된 텍스트: ${texts.join(', ')}`);
    if (texts.length === 0) throw new Error('추출된 텍스트가 없습니다.');

    // 옵션명 번역은 모든 텍스트를 옵션명 지침으로 통합 처리
    console.log(`[Background] 옵션명 텍스트 수: ${texts.length}`);

    // 번역 진행 (옵션명 지침만 사용)
    const translatedTexts = [];
    if (texts.length > 0) {
      const translations = await translateTexts(texts, apiKey, gptModel, instruction);
      texts.forEach((text, i) => {
        // 번역 결과를 지침 그대로 사용 (추가 가공 없음)
        translatedTexts.push(translations[i]);
      });
    }

    console.log(`[Background] 번역된 텍스트: ${translatedTexts.join(', ')}`);

    // 텍스트 교체 (popup.js와 동일한 로직)
    await new Promise((resolve, reject) => {
      chrome.tabs.update(tabId, { active: true }, () => {
        chrome.scripting.executeScript(
          {
            target: { tabId: tabId, allFrames: false },
            function: (originalTexts, translatedTexts) => {
              // popup.js와 동일한 DOM 교체 로직
              const checkedItems = Array.from(document.querySelectorAll('li.ant-list-item'));
              checkedItems.forEach((item, index) => {
                const checkbox = item.querySelector('input[type="checkbox"][checked]');
                if (checkbox) {
                  const span = item.querySelector('span.CharacterSecondary45');
                  const originalText = span ? span.textContent.trim() : null;
                  if (originalText) {
                    const textIndex = originalTexts.indexOf(originalText);
                    if (textIndex !== -1) {
                      const translatedValue = translatedTexts[textIndex];
                      const inputWrapper = item.querySelector('span.ant-input-affix-wrapper');
                      if (inputWrapper) {
                        const input = inputWrapper.querySelector('input.ant-input');
                        if (input) {
                          input.focus();
                          input.select();
                          input.value = translatedValue;
                          input.dispatchEvent(new Event('input', { bubbles: true }));
                          input.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                      }
                    }
                  }
                }
              });
            },
            args: [texts, translatedTexts],
          },
          (results) => {
            if (chrome.runtime.lastError) {
              console.log(`[Background] 리플레이스 오류: ${chrome.runtime.lastError.message}`);
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(results);
            }
          }
        );
      });
    });

    console.log('[Background] 텍스트 교체 완료');

    sendResponse({
      success: true,
      message: '팝업 방식으로 번역 완료!'
    });

  } catch (error) {
    console.error('[Background] 팝업 방식 번역 오류:', error.message);
    sendResponse({
      error: error.message
    });
  }
}

// 청크에서 지침을 불러오는 함수 (popup.js와 동일)
async function loadInstructionFromChunks(key) {
  try {
    const chunkData = await new Promise(resolve => {
      chrome.storage.sync.get([`${key}_chunks`], resolve);
    });
    
    const chunkCount = chunkData[`${key}_chunks`];
    if (!chunkCount) return '';
    
    const chunkKeys = Array.from({ length: chunkCount }, (_, i) => `${key}_chunk_${i}`);
    
    const chunks = await new Promise(resolve => {
      chrome.storage.sync.get(chunkKeys, items => {
        resolve(chunkKeys.map(k => items[k] || ''));
      });
    });
    
    return chunks.join('');
  } catch (error) {
    console.error(`${key} 청크 로드 오류:`, error.message);
    throw error;
  }
}

// 번역 API 호출 함수 (popup.js와 동일)
async function translateTexts(texts, apiKey, gptModel, instruction) {
  const translations = [];
  const finalInstruction = instruction;
  if (!finalInstruction) throw new Error('지침이 설정되지 않았습니다.');

  try {
    const combinedText = texts.join('\n');
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: gptModel || 'gpt-4-turbo-preview',
        messages: [
          { role: 'system', content: finalInstruction },
          { role: 'user', content: `다음 중국어 옵션들을 번역해줘. 각 옵션은 반드시 한 줄로 번역하고, 번호나 불릿 포인트 없이 번역 결과만 출력해주세요. 각 줄은 앞뒤 공백 없이 출력하세요:\n${combinedText}` },
        ],
        temperature: 0.3,
        top_p: 0.95,
        max_tokens: 2000,
      }),
    });
    const data = await response.json();
    if (data.error) throw new Error(data.error.message);

    let translatedLines = data.choices[0].message.content.split('\n');
    
    if (translatedLines.length !== texts.length) {
      console.log(`번역된 줄 수 불일치 감지: 예상 ${texts.length}개, 실제 ${translatedLines.length}개`);
      
      // 줄 수가 더 많은 경우 앞에서부터 필요한 만큼만 사용
      if (translatedLines.length > texts.length) {
        translatedLines = translatedLines.slice(0, texts.length);
      } else {
        // 줄 수가 부족한 경우 재시도
        console.log('번역 재시도 중...');
        return await translateTexts(texts, apiKey, gptModel, instruction);
      }
    }

    translatedLines.forEach((translation, index) => {
      const originalText = texts[index];
      
      // 지침에서만 모든 처리를 하도록 함 (코드 간섭 완전 제거)
      // 단, 지침에 명시된 앞뒤 공백 제거는 코드에서 보장
      const cleanTranslation = translation.trim();
      
      translations.push(cleanTranslation);
      console.log(`[Background] 번역 완료: ${originalText} -> ${cleanTranslation}`);
    });
  } catch (error) {
    console.log(`[Background] 번역 오류: ${error.message}`);
    throw error;
  }
  return translations;
}

// 확장프로그램 설치/시작 시 버전 체크
chrome.runtime.onStartup.addListener(async () => {
  console.log('[자동업데이트] 확장프로그램 시작 - 버전 체크 수행');
  await performBackgroundVersionCheck();
});

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install' || details.reason === 'update') {
    console.log(`[자동업데이트] 확장프로그램 ${details.reason} - 버전 체크 수행`);
    await performBackgroundVersionCheck();
  }
});

// 백그라운드에서 버전 체크 수행
async function performBackgroundVersionCheck() {
  try {
    // VersionChecker 클래스를 동적으로 로드 (version-checker.js와 동일한 구조)
    const versionChecker = new (class VersionChecker {
      constructor() {
        this.GITHUB_API_URL = 'https://api.github.com/repos/ReyFaFa/ShoppyDelight/releases/latest';
        this.GITHUB_REPO_URL = 'https://github.com/ReyFaFa/ShoppyDelight';
        this.CHECK_INTERVAL = 24 * 60 * 60 * 1000; // 24시간
        this.GITHUB_TOKEN = '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'; // Private 레포지토리용 토큰 (하드코딩)
      }

      // 현재 버전 가져오기
      getCurrentVersion() {
        return chrome.runtime.getManifest().version;
      }

      // 버전 비교 (semantic versioning)
      compareVersions(version1, version2) {
        const v1Parts = version1.split('.').map(Number);
        const v2Parts = version2.split('.').map(Number);
        
        for (let i = 0; i < Math.max(v1Parts.length, v2Parts.length); i++) {
          const v1Part = v1Parts[i] || 0;
          const v2Part = v2Parts[i] || 0;
          
          if (v1Part < v2Part) return -1;
          if (v1Part > v2Part) return 1;
        }
        return 0;
      }

      // GitHub 토큰 (하드코딩되어 항상 사용 가능)
      async loadGitHubToken() {
        return this.GITHUB_TOKEN;
      }

      // GitHub API로 최신 릴리즈 확인
      async checkLatestVersion() {
        try {
          // 토큰 로드
          await this.loadGitHubToken();

          const headers = {
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'ShoppyDelight-Extension'
          };

          // Private 레포지토리용 토큰 추가
          if (this.GITHUB_TOKEN) {
            headers['Authorization'] = `token ${this.GITHUB_TOKEN}`;
          }

          const response = await fetch(this.GITHUB_API_URL, {
            method: 'GET',
            headers: headers
          });

          if (!response.ok) {
            if (response.status === 404) {
              console.warn('[백그라운드 버전체크] 릴리즈를 찾을 수 없습니다 (404).');
              return { error: 'NO_RELEASE', status: 404, message: '릴리즈 없음' };
            }
            if (response.status === 401) {
              console.warn('[백그라운드 버전체크] GitHub Token이 유효하지 않습니다 (401).');
              return { error: 'AUTH_FAILED', status: 401, message: 'GitHub Token 오류' };
            }
            console.warn(`[백그라운드 버전체크] GitHub API 오류 (${response.status})`);
            return { error: 'API_ERROR', status: response.status, message: `API 오류: ${response.status}` };
          }

          const data = await response.json();
          return {
            version: data.tag_name.replace(/^v/, ''), // v1.2.0 -> 1.2.0
            downloadUrl: data.html_url,
            releaseNotes: data.body || '',
            publishedAt: data.published_at
          };
        } catch (error) {
          console.error('[백그라운드 버전체크] 연결 오류:', error);
          if (error.message.includes('fetch')) {
            return { error: 'NETWORK_ERROR', message: '네트워크 연결 실패' };
          }
          return { error: 'UNKNOWN_ERROR', message: `알 수 없는 오류: ${error.message}` };
        }
      }

      // 업데이트 필요성 확인
      async checkForUpdates() {
        const currentVersion = await this.getCurrentVersion();
        const latestInfo = await this.checkLatestVersion();
        
        // 오류 상황 처리
        if (latestInfo && latestInfo.error) {
          return { 
            hasUpdate: false, 
            currentVersion,
            error: latestInfo.error,
            errorMessage: latestInfo.message,
            status: latestInfo.status
          };
        }
        
        // null 또는 유효하지 않은 응답
        if (!latestInfo || !latestInfo.version) {
          return { 
            hasUpdate: false, 
            currentVersion,
            error: 'INVALID_RESPONSE',
            errorMessage: '유효하지 않은 응답'
          };
        }

        const hasUpdate = this.compareVersions(currentVersion, latestInfo.version) < 0;
        
        return {
          hasUpdate,
          currentVersion,
          latestVersion: latestInfo.version,
          downloadUrl: latestInfo.downloadUrl,
          releaseNotes: latestInfo.releaseNotes,
          publishedAt: latestInfo.publishedAt
        };
      }

      // 업데이트 정보 저장
      async saveUpdateInfo(updateInfo) {
        return new Promise(resolve => {
          chrome.storage.local.set({ 
            pendingUpdate: updateInfo,
            updateDismissed: false 
          }, resolve);
        });
      }

      // 마지막 체크 시간 저장/조회
      async setLastCheckTime() {
        return new Promise(resolve => {
          chrome.storage.local.set({ lastVersionCheck: Date.now() }, resolve);
        });
      }

      // 주 업데이트 체크 함수
      async performVersionCheck() {
        try {
          console.log('[백그라운드 버전체크] 업데이트 확인 시작...');
          
          const updateInfo = await this.checkForUpdates();
          await this.setLastCheckTime();

          if (updateInfo.hasUpdate) {
            console.log(`[백그라운드 버전체크] 업데이트 발견: ${updateInfo.currentVersion} → ${updateInfo.latestVersion}`);
            await this.saveUpdateInfo(updateInfo);
            return updateInfo;
          } else {
            console.log('[백그라운드 버전체크] 최신 버전입니다.');
            return updateInfo; // null 대신 전체 updateInfo 반환
          }
        } catch (error) {
          console.error('[백그라운드 버전체크] 오류:', error);
          return {
            hasUpdate: false,
            currentVersion: await this.getCurrentVersion(),
            error: 'UNKNOWN_ERROR',
            errorMessage: `알 수 없는 오류: ${error.message}`
          };
        }
      }
    })();

    await versionChecker.performVersionCheck();
  } catch (error) {
    console.error('[백그라운드 버전체크] 초기화 오류:', error);
  }
}

chrome.action.onClicked.addListener((tab) => {
  // 현재 활성 탭 ID 저장 (chrome:// URL이 아닌 경우에만)
  if (tab && tab.id && !tab.url.startsWith('chrome://') && !tab.url.startsWith('edge://')) {
    chrome.storage.local.set({ targetTabId: tab.id });
  }
  
  if (popupWindowId) {
    // 팝업 창이 열려 있으면 닫음
    chrome.windows.remove(popupWindowId, () => {
      popupWindowId = null;
    });
  } else {
    // 현재 브라우저 창의 위치를 기준으로 팝업 위치 계산
    chrome.windows.getCurrent({ populate: false }, (currentWindow) => {
      const popupWidth = 400;
      const popupHeight = 600;
      const marginRight = 10;
      const marginTop = 50; // 브라우저 상단에서 약간 떨어지도록
      const left = currentWindow.left + currentWindow.width - popupWidth - marginRight;
      const top = currentWindow.top + marginTop;
      
      chrome.windows.create({
        url: chrome.runtime.getURL("popup.html"),
        type: "popup",
        width: popupWidth,
        height: popupHeight,
        left: left,
        top: top
      }, (newWindow) => {
        if (chrome.runtime.lastError) {
          console.error('[팝업창 생성 오류]', chrome.runtime.lastError.message);
        } else {
          popupWindowId = newWindow.id;
          console.log('[팝업창] 별도 팝업 창 생성 완료:', newWindow.id);
        }
      });
    });
  }
});

// 강제 파일 업데이트 핸들러
async function handleForceUpdate(files, sendResponse) {
  try {
    console.log('[백그라운드] 혁신적 실시간 업데이트 시작...', files.length, '개 파일');
    
    // Chrome 제약을 우회한 실시간 코드 교체 시스템
    const updateSuccess = await performLiveCodeReplacement(files);
    
    if (updateSuccess) {
      console.log('[백그라운드] 실시간 코드 교체 성공');
      sendResponse({ 
        success: true,
        message: `모든 파일이 실시간으로 업데이트되었습니다. 새로고침하면 새 버전이 적용됩니다.`
      });
    } else {
      throw new Error('실시간 코드 교체에 실패했습니다.');
    }
    
  } catch (error) {
    console.error('[백그라운드] 실시간 업데이트 실패:', error);
    sendResponse({ 
      success: false, 
      error: error.message 
    });
  }
}

// 혁신적 실시간 코드 교체 시스템
async function performLiveCodeReplacement(files) {
  try {
    console.log('[백그라운드] 실시간 코드 주입 시작...');
    
    let successCount = 0;
    
    for (const file of files) {
      try {
        // GitHub에서 최신 파일 내용 가져오기
        const response = await fetch(file.download_url);
        const newContent = await response.text();
        
        console.log(`[백그라운드] 파일 다운로드 완료: ${file.name}`);
        
        // 파일 유형별 실시간 교체
        if (file.name === 'manifest.json') {
          // manifest.json의 경우 버전 정보를 runtime에 강제 주입
          await injectManifestUpdate(newContent);
          console.log('[백그라운드] manifest.json 런타임 업데이트 완료');
        } 
        else if (file.name.endsWith('.js')) {
          // JavaScript 파일의 경우 동적 교체
          await injectScriptUpdate(file.name, newContent);
          console.log(`[백그라운드] ${file.name} 스크립트 교체 완료`);
        } 
        else if (file.name.endsWith('.html')) {
          // HTML 파일의 경우 DOM 교체
          await injectHTMLUpdate(file.name, newContent);
          console.log(`[백그라운드] ${file.name} DOM 교체 완료`);
        }
        
        successCount++;
        
      } catch (error) {
        console.error(`[백그라운드] ${file.name} 교체 실패:`, error);
      }
    }
    
    console.log(`[백그라운드] 실시간 교체 완료: ${successCount}/${files.length} 성공`);
    return successCount === files.length;
    
  } catch (error) {
    console.error('[백그라운드] 실시간 코드 교체 실패:', error);
    return false;
  }
}

// manifest.json 런타임 버전 강제 주입
async function injectManifestUpdate(newContent) {
  try {
    const newManifest = JSON.parse(newContent);
    
    // Runtime 객체에 새 버전 정보 강제 주입
    Object.defineProperty(chrome.runtime.getManifest(), 'version', {
      value: newManifest.version,
      writable: false,
      configurable: true
    });
    
    // Storage에 새 버전 정보 저장
    await chrome.storage.local.set({
      'runtime_version_override': newManifest.version,
      'manifest_updated': Date.now()
    });
    
    console.log(`[백그라운드] 런타임 버전 강제 업데이트: ${newManifest.version}`);
    
  } catch (error) {
    console.error('[백그라운드] manifest 주입 실패:', error);
    throw error;
  }
}

// 스크립트 동적 교체
async function injectScriptUpdate(fileName, newContent) {
  try {
    // 새로운 스크립트 내용을 Storage에 저장
    const storageKey = `updated_script_${fileName}`;
    
    await chrome.storage.local.set({
      [storageKey]: {
        content: newContent,
        timestamp: Date.now(),
        active: true
      }
    });
    
    console.log(`[백그라운드] ${fileName} 스크립트 저장 완료`);
    
  } catch (error) {
    console.error(`[백그라운드] ${fileName} 스크립트 주입 실패:`, error);
    throw error;
  }
}

// HTML DOM 동적 교체
async function injectHTMLUpdate(fileName, newContent) {
  try {
    // HTML 내용을 Storage에 저장
    const storageKey = `updated_html_${fileName}`;
    
    await chrome.storage.local.set({
      [storageKey]: {
        content: newContent,
        timestamp: Date.now(),
        active: true
      }
    });
    
    console.log(`[백그라운드] ${fileName} HTML 저장 완료`);
    
  } catch (error) {
    console.error(`[백그라운드] ${fileName} HTML 주입 실패:`, error);
    throw error;
  }
}

// 강제 재시작 핸들러
async function handleForceRestart(sendResponse) {
  try {
    console.log('[백그라운드] 강제 재시작 요청 수신');
    
    // 저장된 업데이트 상태 정리
    await chrome.storage.local.remove(['pendingUpdate', 'updateDismissed']);
    
    // 재시작 성공 응답
    sendResponse({ success: true });
    
    // 응답 후 짧은 지연 후에 재시작 실행
    setTimeout(() => {
      console.log('[백그라운드] chrome.runtime.reload() 실행');
      if (chrome.runtime && chrome.runtime.reload) {
        chrome.runtime.reload();
      }
    }, 1000);
    
  } catch (error) {
    console.error('[백그라운드] 강제 재시작 실패:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// 동적 스크립트 실행 핸들러 (CSP 제약 우회)
async function handleExecuteUpdatedScript(fileName, content, sendResponse) {
  try {
    console.log(`[백그라운드] 동적 스크립트 실행 요청: ${fileName}`);
    
    // CSP 제약으로 인해 동적 스크립트 실행을 단순화
    // 대신 업데이트된 스크립트 내용을 storage에 저장하여 다음 로드 시 사용
    const storageKey = `updated_script_${fileName}`;
    
    await chrome.storage.local.set({
      [storageKey]: {
        content: content,
        timestamp: Date.now(),
        updated: true
      }
    });
    
    console.log(`[백그라운드] 스크립트 저장 완료: ${fileName} (다음 로드 시 적용)`);
    
    sendResponse({ 
      success: true, 
      message: `스크립트가 저장되었습니다. 재시작 후 적용됩니다.` 
    });
    
  } catch (error) {
    console.error(`[백그라운드] 동적 스크립트 실행 실패 ${fileName}:`, error);
    sendResponse({ 
      success: false, 
      error: error.message 
    });
  }
}
