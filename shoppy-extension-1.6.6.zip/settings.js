document.addEventListener('DOMContentLoaded', () => {
  const apiKeyInput = document.getElementById('apiKey');
  const gptModelSelect = document.getElementById('gptModel');
  const instructionTextarea = document.getElementById('instruction');
  const productInstructionTextarea = document.getElementById('productInstruction');
  const shortcutKeyInput = document.getElementById('shortcutKey');
  const saveButton = document.getElementById('saveButton');
  const clearLogButton = document.getElementById('clearLogButton');
  const logText = document.getElementById('logText');

  // 로그 함수
  async function log(message) {
    const timestamp = new Date().toLocaleTimeString();
    const logMessage = `[${timestamp}] ${message}\n`;
    
    logText.value += logMessage;
    logText.scrollTop = logText.scrollHeight;

    const logs = await new Promise(resolve => chrome.storage.local.get(['logs'], result => resolve(result.logs || '')));
    const logLines = logs.split('\n').slice(-1000).join('\n') + logMessage;
    await new Promise(resolve => chrome.storage.local.set({ logs: logLines }, resolve));
  }

  // 저장된 로그 로드
  chrome.storage.local.get(['logs'], (result) => {
    logText.value = result.logs || '';
    logText.scrollTop = logText.scrollHeight;
  });

  // 저장 버튼 클릭 시 설정 저장
  saveButton.addEventListener('click', async () => {
    const apiKey = apiKeyInput.value.trim();
    const gptModel = gptModelSelect.value;
    const instruction = instructionTextarea.value.trim();
    const productInstruction = productInstructionTextarea.value.trim();
    const shortcutKey = shortcutKeyInput.value.trim();

    // 저장 전 로그에 기록
    log(`저장 시도: 옵션명 지침 길이 - ${instruction.length}, 상품명 지침 길이 - ${productInstruction.length}`);

    try {
      // 기본 설정 저장
      await new Promise((resolve, reject) => {
        chrome.storage.sync.set({ apiKey, gptModel, shortcutKey }, () => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve();
        });
      });
      
      // 옵션명 지침을 청크로 분할하여 저장
      await saveInstructionInChunks('instruction', instruction);
      
      // 상품명 지침을 청크로 분할하여 저장
      await saveInstructionInChunks('productInstruction', productInstruction);
      
      // 저장 확인을 위해 다시 불러오기
      const loadedInstruction = await loadInstructionFromChunks('instruction');
      const loadedProductInstruction = await loadInstructionFromChunks('productInstruction');
      
      log(`저장 확인: 옵션명 지침 ${loadedInstruction === instruction ? '정상' : '오류'}, 상품명 지침 ${loadedProductInstruction === productInstruction ? '정상' : '오류'}`);
      
      if (loadedInstruction !== instruction || loadedProductInstruction !== productInstruction) {
        log('경고: 저장된 지침이 입력한 지침과 다릅니다');
        alert('지침 저장이 제대로 되지 않았습니다. 다시 시도해주세요.');
      } else {
        log(`설정 저장: API 키 - ${apiKey ? '설정됨' : '없음'}, 모델 - ${gptModel}, 옵션명 지침 - 저장됨(${instruction.length}자), 상품명 지침 - 저장됨(${productInstruction.length}자), 단축키 - ${shortcutKey}`);
        alert('설정이 저장되었습니다.');
      }
      
      // 단축키 업데이트
      chrome.runtime.sendMessage({ action: 'updateShortcut', shortcutKey });
      
    } catch (error) {
      log(`저장 오류: ${error.message}`);
      alert(`저장 중 오류 발생: ${error.message}`);
    }
  });

  // 지침을 청크로 분할하여 저장하는 함수
  async function saveInstructionInChunks(key, value) {
    // 청크 크기: 1KB로 축소 (크기를 더 작게 설정)
    const chunkSize = 1000;
    const chunks = [];
    
    // 청크로 분할
    for (let i = 0; i < value.length; i += chunkSize) {
      chunks.push(value.substring(i, i + chunkSize));
    }
    
    try {
      // 기존 청크 키 삭제
      const allKeys = await new Promise(resolve => {
        chrome.storage.sync.get(null, items => {
          resolve(Object.keys(items).filter(k => k.startsWith(`${key}_chunk_`)));
        });
      });
      
      if (allKeys.length > 0) {
        await new Promise((resolve, reject) => {
          chrome.storage.sync.remove(allKeys, () => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve();
          });
        });
      }
      
      log(`${key} 청크 개수: ${chunks.length}개`);
      
      // 청크 개수 저장
      await new Promise((resolve, reject) => {
        chrome.storage.sync.set({ [`${key}_chunks`]: chunks.length }, () => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve();
        });
      });
      
      // 각 청크 순차적으로 저장 (개별 오류 처리)
      let failedChunks = 0;
      for (let i = 0; i < chunks.length; i++) {
        try {
          await new Promise((resolve, reject) => {
            chrome.storage.sync.set({ [`${key}_chunk_${i}`]: chunks[i] }, () => {
              if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
              else resolve();
            });
          });
          // 각 청크 저장 후 짧은 지연 추가 (스토리지 API 부하 감소)
          await new Promise(r => setTimeout(r, 50));
        } catch (error) {
          failedChunks++;
          log(`청크 ${i} 저장 실패: ${error.message}`);
        }
      }
      
      if (failedChunks > 0) {
        throw new Error(`${failedChunks}개의 청크 저장에 실패했습니다.`);
      }
      
      log(`${key} 저장 완료: ${chunks.length}개 청크로 분할됨`);
    } catch (error) {
      log(`${key} 청크 저장 오류: ${error.message}`);
      throw error;
    }
  }

  // 청크에서 지침을 불러오는 함수
  async function loadInstructionFromChunks(key) {
    try {
      // 청크 개수 확인
      const { [`${key}_chunks`]: chunkCount } = await new Promise(resolve => {
        chrome.storage.sync.get([`${key}_chunks`], resolve);
      });
      
      if (!chunkCount) return '';
      
      // 청크 키 생성
      const chunkKeys = Array.from({ length: chunkCount }, (_, i) => `${key}_chunk_${i}`);
      
      // 모든 청크 로드
      const chunks = await new Promise(resolve => {
        chrome.storage.sync.get(chunkKeys, items => {
          resolve(chunkKeys.map(k => items[k] || ''));
        });
      });
      
      // 청크 합치기
      return chunks.join('');
    } catch (error) {
      log(`${key} 청크 로드 오류: ${error.message}`);
      throw error;
    }
  }

  // 저장된 설정 로드 (수정됨)
  async function loadSettings() {
    try {
      // 기본 설정 로드
      const { apiKey, gptModel, shortcutKey } = await new Promise(resolve => {
        chrome.storage.sync.get(['apiKey', 'gptModel', 'shortcutKey'], resolve);
      });
      
      // 옵션명 지침 로드
      const instruction = await loadInstructionFromChunks('instruction');
      
      // 상품명 지침 로드
      const productInstruction = await loadInstructionFromChunks('productInstruction');
      
      // 기본 지침 설정
      const defaultInstruction = `# 중국어 옵션 번역 지침 — 실행 사양 (22자 엄격)

## 0) 출력 계약(Contract)

* **최종 출력은 한 줄 문자열 1개(한국어)**만.
* 앞·뒤 공백 제거, 맨앞 '-' 금지, 넘버링 금지(예: '1.', 'A)', '(3)' 등).
* 허용 문자/기호만 사용: 한글/숫자/영문 + 공백 + '~ ( ) . _ - + /'

  * 위 목록 외 특수문자 사용 금지.

## 1) 절대 규칙

1. 22자 이하(공백 포함). 23자 이상이면 실패 또는 재축약.
2. 번역 후 글자수 반드시 검증.
3. 브랜드/모델 임의 추가 금지. 의미 없는 수식어 금지(프리미엄, 정품급 등).
4. 사이즈는 유지. 단, 모든 옵션이 동일한 사이즈일 때만 생략 가능.

## 2) 표기/변환 규칙

* 색상 맵: 黑色→블랙, 粉色→핑크, 黑胡桃色→블랙월넛, 家居色→네추럴
* 사이즈: '* → x' (예: '25*50*10 → 25x50x10cm'), 'cm'는 마지막에 1회만 표기
* 단위: 平→평, 公斤→kg, 斤→0.5kg, 120升→120형(리터 금지)
* 의류 사이즈: 'xs/s/m/l/xl' → 대문자(XS, S, M, L, XL)
* 구분 기호: 항목 구분 '-', 결합/묶음 '+' 사용
  (원문에 없는 '-/( )'는 최종 결과에서 불필요하면 제거, '+'는 유지 가능)

## 3) 22자 초과 시 축약 사다리(순서 고정)

1. 공통 불필요어 삭제(프리미엄/기본/고급/정품급/기능/효과/포함/용 등)
2. 중복 의미 통합(유사 의미 중 하나만 남김)
3. 핵심 단어 축약(스테인리스스틸→스텐, 손수레식→손수레 등)
4. 조사/어미 삭제(…하는/의/을/를 등)
5. 숫자·모델 간소화(의미 훼손 없이 불필요 접미/0 제거)
6. 여전히 초과 시 부차 속성부터 희생(색상·수식어 등)
   ※ 사이즈는 옵션 구분 핵심이면 반드시 유지.

## 4) 처리 순서(알고리즘)

1. 정규화: 트림 → 맨앞 넘버링 제거 → 연속 공백 1칸으로.
2. 파싱: 색상/치수/재질/기능 등 핵심 속성 식별.
3. 변환: §2의 맵·규칙 적용('*→x', 단위/색상/사이즈 대문자화).
4. 구성: 의미가 잘 드러나게 간결 조합(필요 시 '-'/'+ ' 사용).
5. 축약: 길이>22면 §3 순서대로 반복 적용.
6. 검증: 길이, 허용문자, 넘버링·선두 하이픈 여부 최종 체크.

## 5) 검증 체크리스트(정규식)

* 넘버링 제거용(전처리)
  '^\\s*(?:\\d+[\\.\\)\\s*|[A-Da-d][\\.\\)\\s*|\\(\\d+\\)\\s*)+'
* 허용문자 검사(미허용 탐지)
  '[^ㄱ-ㅎ가-힣A-Za-z0-9 ~()._\\-+\\/]' → 존재 시 실패
* 맨앞 하이픈 금지
  '^\\s*-' → 실패
* 별표 치수 통일
  '\\s*\\*\\s*' → 'x'
* 연속 공백 1칸
  '\\s{2,}' → ' '
* 길이 검사
  'str.length <= 22'

특수문자는 다음 허용문자외 절대 사용금지: ~ (). _- + /
상품명 맨앞, 맨뒤 공백 제거, 맨앞 '-' 사용금지`;

      const defaultProductInstruction = `중국어 옵션명을 네이버 쇼핑 상품명에 적합하도록 한국인에게 친숙한 키워드들로 바꿔서(의역) 네이버쇼핑 SEO에 맞는 상품명으로 만들어줘
상품과 연관없는 불필요한 단어는 삭제하고, 글자수는 가급적 35자~45자 내외로 조정해줘
키워드 조정 전략

상품 관련성 유지: 상품과 직접 연관된 키워드만 사용(예: "스텐", "원목", "수납장")하며, 무관한 인기 키워드(예: "최신", "추천") 배제.
구체성 강화: "가구", "장비" 대신 "화장대", "협탁", "트롤리" 등 상품의 핵심 특성을 드러내는 단어 선택.
검색 의도 반영: 사용자 검색 패턴(예: "호텔 매립등 침대", "L자 컴퓨터 책상")을 고려해 직관적 조합.
상품명 단어중 연관이 적은 불필요 단어는 삭제하고, 상품명과 관련있는 키워드 추가해서 구성
중복 제거: "테이블", "의자"처럼 반복되는 단어는 통합하거나 생략해 간결하게 정리.
SEO 최적화: 네이버 쇼핑에서 검색량 높은 키워드(예: "빈티지", "스탠드", "엔틱")를 상품 특성에 맞춰 활용, 경쟁도 높은 포화 키워드는 피함.
키워드 배치가 끝난 상품명은 읽기가 자연스러운 형태여야한다.
상품명에 년도가 나오면 삭제
최종 결과물은 위 지침을 준수한 반드시 한글 번역이야 한다
번역된 최종 결과물 앞에 임의의 넘버링 금지, 번역된 글자만 나오도록`;

      // UI 업데이트
      apiKeyInput.value = apiKey || '';
      gptModelSelect.value = gptModel || 'gpt-4o';
      instructionTextarea.value = instruction || defaultInstruction;
      productInstructionTextarea.value = productInstruction || defaultProductInstruction;
      shortcutKeyInput.value = shortcutKey || 'F2';
      
      log(`설정 로드: API 키 - ${apiKey ? '설정됨' : '없음'}, 모델 - ${gptModel || '없음'}, 옵션명 지침 - 로드됨(${instruction.length}자), 상품명 지침 - 로드됨(${productInstruction.length}자), 단축키 - ${shortcutKey || '없음'}`);
    } catch (error) {
      log(`설정 로드 오류: ${error.message}`);
    }
  }

  // 최초 로드
  loadSettings();

  // 로그 지우기 버튼 클릭 시
  clearLogButton.addEventListener('click', () => {
    chrome.storage.local.set({ logs: '' }, () => {
      logText.value = '';
      log('로그가 지워졌습니다.');
    });
  });
});
