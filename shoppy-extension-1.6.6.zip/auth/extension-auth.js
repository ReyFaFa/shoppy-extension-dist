/**
 * Shoppy Extension Authentication Module
 * Chrome Extension에서 사용하는 OAuth + JWT 인증 시스템
 */

class ShoppyAuth {
  constructor() {
    this.licenseServer = 'https://shoppydelight-license-server.onrender.com';
    this.storage = chrome.storage.local;
    this.tokenKey = 'shoppy_license_token';
    this.userKey = 'shoppy_user_info';
    this.deviceKey = 'shoppy_device_info';

    this.init();
  }

  /**
   * 초기화
   */
  async init() {
    // 기기 정보 생성
    const deviceInfo = await this.getOrCreateDeviceInfo();
    await this.storage.set({ [this.deviceKey]: deviceInfo });

    // 토큰 유효성 주기적 검사 (5분마다)
    setInterval(() => this.validateToken(), 5 * 60 * 1000);
  }

  /**
   * 기기 정보 생성 또는 가져오기
   */
  async getOrCreateDeviceInfo() {
    const stored = await this.storage.get(this.deviceKey);

    if (stored[this.deviceKey]) {
      return stored[this.deviceKey];
    }

    const deviceInfo = {
      id: this.generateDeviceId(),
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      language: navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      createdAt: Date.now()
    };

    return deviceInfo;
  }

  /**
   * 고유한 기기 ID 생성
   */
  generateDeviceId() {
    const data = `${navigator.userAgent}${navigator.platform}${navigator.language}${Date.now()}`;
    return this.hashString(data);
  }

  /**
   * 문자열 해시 생성
   */
  async hashString(str) {
    const encoder = new TextEncoder();
    const data = encoder.encode(str);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * OAuth 인증 시작
   */
  async startAuthentication() {
    try {
      const deviceInfo = await this.getDeviceInfo();
      const extensionId = chrome.runtime.id;

      const response = await fetch(`${this.licenseServer}/auth/google/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          extensionId,
          deviceInfo
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Authentication start failed');
      }

      // 새 탭에서 OAuth 페이지 열기
      const authTab = await chrome.tabs.create({
        url: data.authUrl,
        active: true
      });

      // 인증 완료 대기
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Authentication timeout'));
        }, 5 * 60 * 1000); // 5분 타임아웃

        const listener = (tabId, changeInfo, tab) => {
          if (tabId === authTab.id && changeInfo.url) {
            if (changeInfo.url.includes('/auth/success')) {
              clearTimeout(timeout);
              chrome.tabs.onUpdated.removeListener(listener);
              chrome.tabs.remove(tabId);
              resolve(this.handleAuthSuccess(changeInfo.url));
            } else if (changeInfo.url.includes('/auth/error')) {
              clearTimeout(timeout);
              chrome.tabs.onUpdated.removeListener(listener);
              chrome.tabs.remove(tabId);
              reject(new Error('Authentication failed'));
            }
          }
        };

        chrome.tabs.onUpdated.addListener(listener);
      });

    } catch (error) {
      console.error('Authentication error:', error);
      throw error;
    }
  }

  /**
   * 인증 성공 처리
   */
  async handleAuthSuccess(url) {
    const urlObj = new URL(url);
    const token = urlObj.searchParams.get('token');
    const userInfo = JSON.parse(urlObj.searchParams.get('user') || '{}');

    if (!token) {
      throw new Error('No token received');
    }

    // 토큰과 사용자 정보 저장
    await this.storage.set({
      [this.tokenKey]: token,
      [this.userKey]: userInfo
    });

    console.log('Authentication successful:', userInfo);
    return { token, user: userInfo };
  }

  /**
   * 현재 토큰 가져오기
   */
  async getToken() {
    const stored = await this.storage.get(this.tokenKey);
    return stored[this.tokenKey];
  }

  /**
   * 사용자 정보 가져오기
   */
  async getUserInfo() {
    const stored = await this.storage.get(this.userKey);
    return stored[this.userKey];
  }

  /**
   * 기기 정보 가져오기
   */
  async getDeviceInfo() {
    const stored = await this.storage.get(this.deviceKey);
    return stored[this.deviceKey];
  }

  /**
   * 토큰 유효성 검증
   */
  async validateToken() {
    const token = await this.getToken();

    if (!token) {
      return false;
    }

    try {
      const response = await fetch(`${this.licenseServer}/auth/verify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ token })
      });

      const data = await response.json();

      if (response.ok && data.valid) {
        // 토큰이 유효함
        return true;
      } else {
        // 토큰이 무효함 - 저장된 토큰 제거
        await this.clearAuth();
        return false;
      }

    } catch (error) {
      console.error('Token validation error:', error);
      return false;
    }
  }

  /**
   * 토큰 갱신
   */
  async refreshToken() {
    const token = await this.getToken();

    if (!token) {
      throw new Error('No token to refresh');
    }

    try {
      const response = await fetch(`${this.licenseServer}/auth/refresh`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ token })
      });

      const data = await response.json();

      if (response.ok) {
        // 새 토큰 저장
        await this.storage.set({ [this.tokenKey]: data.token });
        return data.token;
      } else {
        throw new Error(data.error || 'Token refresh failed');
      }

    } catch (error) {
      console.error('Token refresh error:', error);
      throw error;
    }
  }

  /**
   * 권한 확인
   */
  async hasPermission(permission) {
    const isValid = await this.validateToken();

    if (!isValid) {
      return false;
    }

    const token = await this.getToken();

    // JWT 토큰 파싱 (간단한 파싱, 서버 검증이 우선)
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.permissions && payload.permissions.includes(permission);
    } catch (error) {
      console.error('Token parsing error:', error);
      return false;
    }
  }

  /**
   * 인증 상태 확인
   */
  async isAuthenticated() {
    return await this.validateToken();
  }

  /**
   * 로그아웃 (인증 정보 제거)
   */
  async logout() {
    await this.clearAuth();
  }

  /**
   * 인증 정보 제거
   */
  async clearAuth() {
    await this.storage.remove([this.tokenKey, this.userKey]);
  }

  /**
   * 기능 게이트 - 토큰 검증 후 콜백 실행
   */
  async withAuth(callback, requiredPermission = null) {
    const isAuth = await this.isAuthenticated();

    if (!isAuth) {
      throw new Error('Authentication required');
    }

    if (requiredPermission) {
      const hasPermission = await this.hasPermission(requiredPermission);
      if (!hasPermission) {
        throw new Error(`Permission required: ${requiredPermission}`);
      }
    }

    return callback();
  }

  /**
   * 인증 필요 알림 표시
   */
  async showAuthRequired() {
    const notification = {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icon48.png'),
      title: 'Shoppy Extension - 인증 필요',
      message: '이 기능을 사용하려면 로그인이 필요합니다. Extension을 클릭하여 로그인해주세요.'
    };

    if (chrome.notifications) {
      chrome.notifications.create('auth_required', notification);
    }
  }

  /**
   * 권한 없음 알림 표시
   */
  async showPermissionDenied(permission) {
    const notification = {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icon48.png'),
      title: 'Shoppy Extension - 권한 없음',
      message: `이 기능(${permission})을 사용할 권한이 없습니다. 라이선스를 확인해주세요.`
    };

    if (chrome.notifications) {
      chrome.notifications.create('permission_denied', notification);
    }
  }
}

// 전역 인스턴스 생성
const shoppyAuth = new ShoppyAuth();

// Extension에서 사용할 수 있도록 전역 객체에 추가
if (typeof window !== 'undefined') {
  window.shoppyAuth = shoppyAuth;
}

// Node.js 환경에서 사용할 수 있도록 export
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ShoppyAuth;
}