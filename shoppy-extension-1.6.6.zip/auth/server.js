#!/usr/bin/env node

/**
 * Shoppy Extension License Server
 * OAuth 2.0 + JWT 기반 라이선스 관리 시스템
 */

const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

// Environment variables
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(64).toString('hex');
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;

// Middleware
app.use(cors({
  origin: ['chrome-extension://*', 'https://reyfafa.github.io'],
  credentials: true
}));
app.use(express.json());

// In-memory storage (replace with database in production)
const users = new Map();
const licenses = new Map();
const deviceFingerprints = new Map();

/**
 * 기기 핑거프린트 생성
 */
function generateDeviceFingerprint(userAgent, clientIP, extensionId) {
  const data = `${userAgent}|${clientIP}|${extensionId}`;
  return crypto.createHash('sha256').update(data).digest('hex');
}

/**
 * JWT 토큰 생성
 */
function generateLicenseToken(userId, deviceId, permissions = ['basic']) {
  const payload = {
    sub: userId,
    device: deviceId,
    permissions,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + (30 * 24 * 60 * 60), // 30일
    iss: 'shoppy-extension-license-server',
    aud: 'shoppy-extension',
    jti: uuidv4()
  };

  return jwt.sign(payload, JWT_SECRET, { algorithm: 'HS256' });
}

/**
 * JWT 토큰 검증
 */
function verifyLicenseToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

// Routes

/**
 * Health check
 */
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

/**
 * OAuth 시작 (Google OAuth 2.0)
 */
app.post('/auth/google/start', (req, res) => {
  const { extensionId, deviceInfo } = req.body;

  if (!extensionId) {
    return res.status(400).json({ error: 'Extension ID required' });
  }

  // Generate state for CSRF protection
  const state = uuidv4();

  // Store state temporarily (should use Redis in production)
  const authSession = {
    state,
    extensionId,
    deviceInfo,
    createdAt: Date.now()
  };

  // Google OAuth URL
  const googleOAuthURL = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  googleOAuthURL.searchParams.set('client_id', GOOGLE_CLIENT_ID);
  googleOAuthURL.searchParams.set('redirect_uri', 'http://localhost:3000/auth/google/callback');
  googleOAuthURL.searchParams.set('response_type', 'code');
  googleOAuthURL.searchParams.set('scope', 'openid email profile');
  googleOAuthURL.searchParams.set('state', state);

  res.json({
    authUrl: googleOAuthURL.toString(),
    state: state
  });
});

/**
 * OAuth 콜백 (Google)
 */
app.post('/auth/google/callback', async (req, res) => {
  const { code, state } = req.body;

  if (!code || !state) {
    return res.status(400).json({ error: 'Missing authorization code or state' });
  }

  try {
    // Exchange code for tokens (simplified - implement actual Google OAuth flow)
    const userInfo = {
      id: 'google_' + crypto.randomUUID(),
      email: 'user@example.com', // Would come from Google API
      name: 'Test User'
    };

    // Generate device fingerprint
    const userAgent = req.headers['user-agent'] || '';
    const clientIP = req.ip || req.connection.remoteAddress || '';
    const deviceId = generateDeviceFingerprint(userAgent, clientIP, 'extension_id');

    // Create or update user
    users.set(userInfo.id, {
      ...userInfo,
      createdAt: Date.now(),
      lastLogin: Date.now()
    });

    // Create license
    const licenseId = uuidv4();
    const license = {
      id: licenseId,
      userId: userInfo.id,
      deviceId: deviceId,
      status: 'active',
      permissions: ['basic', 'translate', 'bulk_translate'],
      createdAt: Date.now(),
      expiresAt: Date.now() + (30 * 24 * 60 * 60 * 1000), // 30일
      lastUsed: Date.now()
    };

    licenses.set(licenseId, license);
    deviceFingerprints.set(deviceId, {
      userId: userInfo.id,
      licenseId: licenseId,
      userAgent,
      clientIP,
      firstSeen: Date.now(),
      lastSeen: Date.now()
    });

    // Generate JWT token
    const token = generateLicenseToken(userInfo.id, deviceId, license.permissions);

    res.json({
      success: true,
      token: token,
      user: {
        id: userInfo.id,
        email: userInfo.email,
        name: userInfo.name
      },
      license: {
        id: licenseId,
        status: license.status,
        permissions: license.permissions,
        expiresAt: license.expiresAt
      }
    });

  } catch (error) {
    console.error('OAuth callback error:', error);
    res.status(500).json({ error: 'Authentication failed' });
  }
});

/**
 * 토큰 검증
 */
app.post('/auth/verify', (req, res) => {
  const { token } = req.body;

  if (!token) {
    return res.status(400).json({ error: 'Token required' });
  }

  const payload = verifyLicenseToken(token);

  if (!payload) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  // Check license status
  const license = Array.from(licenses.values()).find(l =>
    l.userId === payload.sub && l.deviceId === payload.device
  );

  if (!license || license.status !== 'active') {
    return res.status(403).json({ error: 'License inactive or revoked' });
  }

  // Update last used
  license.lastUsed = Date.now();

  res.json({
    valid: true,
    user: payload.sub,
    device: payload.device,
    permissions: payload.permissions,
    expiresAt: payload.exp * 1000
  });
});

/**
 * 토큰 갱신
 */
app.post('/auth/refresh', (req, res) => {
  const { token } = req.body;

  if (!token) {
    return res.status(400).json({ error: 'Token required' });
  }

  const payload = verifyLicenseToken(token);

  if (!payload) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  // Check if token is close to expiry (within 7 days)
  const timeToExpiry = payload.exp * 1000 - Date.now();
  const sevenDays = 7 * 24 * 60 * 60 * 1000;

  if (timeToExpiry > sevenDays) {
    return res.status(400).json({ error: 'Token not eligible for refresh yet' });
  }

  // Generate new token
  const newToken = generateLicenseToken(payload.sub, payload.device, payload.permissions);

  res.json({
    token: newToken,
    expiresAt: (Math.floor(Date.now() / 1000) + (30 * 24 * 60 * 60)) * 1000
  });
});

/**
 * 라이선스 상태 확인
 */
app.get('/license/status/:userId', (req, res) => {
  const { userId } = req.params;

  const userLicenses = Array.from(licenses.values()).filter(l => l.userId === userId);

  res.json({
    userId,
    licenses: userLicenses.map(l => ({
      id: l.id,
      status: l.status,
      permissions: l.permissions,
      expiresAt: l.expiresAt,
      lastUsed: l.lastUsed
    }))
  });
});

/**
 * 관리자: 라이선스 취소
 */
app.post('/admin/license/revoke', (req, res) => {
  const { licenseId, reason } = req.body;

  const license = licenses.get(licenseId);

  if (!license) {
    return res.status(404).json({ error: 'License not found' });
  }

  license.status = 'revoked';
  license.revokedAt = Date.now();
  license.revokeReason = reason || 'Admin action';

  res.json({
    success: true,
    licenseId,
    status: 'revoked'
  });
});

/**
 * 관리자: 통계
 */
app.get('/admin/stats', (req, res) => {
  const stats = {
    totalUsers: users.size,
    totalLicenses: licenses.size,
    activeLicenses: Array.from(licenses.values()).filter(l => l.status === 'active').length,
    revokedLicenses: Array.from(licenses.values()).filter(l => l.status === 'revoked').length,
    totalDevices: deviceFingerprints.size
  };

  res.json(stats);
});

// Error handling
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Shoppy Extension License Server running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
  console.log(`🔐 JWT Secret: ${JWT_SECRET.substring(0, 20)}...`);
});

module.exports = app;